package taf.te.util;

public class TAFException extends Throwable {
	private static final long serialVersionUID = 1L;
	
	private ProcessingCode pc;
	private String message;
	
	public TAFException(ProcessingCode pc, String message) {
		this.pc = pc;
		this.message = message;
	}
	
	public TAFException(Throwable ex) {
		pc = ProcessingCode.INVALID_CONTENTS;
		message = ex.getMessage();
	}
	
	public ProcessingCode getPC() {
		return pc;
	}
	
	public String getMessage() {
		return message;
	}
}

package taf.te.interfaces;

import taf.te.util.UTF8String;

public interface InputData {
	UTF8String getValue(String name);
}

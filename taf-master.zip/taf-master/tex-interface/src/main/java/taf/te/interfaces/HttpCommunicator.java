package taf.te.interfaces;

import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public interface HttpCommunicator {
	public static final String METHOD_GET = "GET";
	public static final String METHOD_POST = "POST";

	public static final String HDR_ACCEPT = "Accept";
	public static final String HDR_CONTENT_TYPE = "Content-Type";
	public static final String HDR_VAL_APPJSON = "application/json";

	public void setHostParams(String host, boolean bSSL);
	public void setMethod(String method);
	
	public void addPath(String path);
	public void addContent(String content);
	public void addHeader(String pn, String pv);
	public void addQuerryParameter(String parameter, String value);
	public void setPostData(String postData);
	public int getResponseCode();

	public UTF8String send(TAFLogger logger, int retryCount, int retrySleepMS) throws TAFException;
}

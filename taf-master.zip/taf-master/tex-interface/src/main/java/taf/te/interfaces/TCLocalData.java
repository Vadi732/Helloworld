package taf.te.interfaces;

public interface TCLocalData {
	Object getValue(String name);
	void putValue(String name, Object value);
}

package taf.te.util;

public enum ProcessingCode {
	SUCCESS(0),
	INVALID_CONTENTS(1),
	HTTP_ERROR(2),
	FAILED_TO_LOAD_JAR_FILE(3),
	FAILED_TO_LOAD_EXEC_CLASS(4),

	UNKNOWN(-1);
	private int value;
	private static final ProcessingCode[] vals = ProcessingCode.values();

	private ProcessingCode(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public static ProcessingCode get(int value) {
		for (ProcessingCode e : ProcessingCode.vals) {
			if (e.getValue() == value)
				return e;
		}
		return UNKNOWN;
	}
}

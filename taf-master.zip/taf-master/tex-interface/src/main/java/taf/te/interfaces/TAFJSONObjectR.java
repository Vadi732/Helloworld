package taf.te.interfaces;

import java.util.Set;

import taf.te.util.UTF8String;

public interface TAFJSONObjectR {
	public Set<String> getKeys();
	public TAFJSONObjectR getMandatoryObject(String name);
	public TAFJSONArrayR getMandatoryArray(String name);
	public int getMandatoryIntValue(String name);
	public long getMandatoryLongValue(String name);
	public UTF8String getMandatoryStrValue(String name);

	public TAFJSONObjectR getOptionalObject(String name);
	public TAFJSONArrayR getOptionalArray(String name);
	public int getOptionalIntValue(String name, int defVal);
	public long getOptionalLongValue(String name, long defVal);
	public UTF8String getOptionalStrValue(String name, String defVal);
}

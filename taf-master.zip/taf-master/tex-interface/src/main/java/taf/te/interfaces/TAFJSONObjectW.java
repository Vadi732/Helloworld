package taf.te.interfaces;

import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public interface TAFJSONObjectW {
	public TAFJSONObjectW addAndGetObject(String name) throws TAFException;
	public TAFJSONArrayW addAndGetArray(String name) throws TAFException;
	public void addLongValue(String name, Long val) throws TAFException;
	public void addIntValue(String name, Integer val) throws TAFException;
	public void addDoubleValue(String name, Double val) throws TAFException;
	public void addStrValue(String name, UTF8String val) throws TAFException;
}

package taf.te.interfaces;

import java.util.List;
import java.util.Map;
import java.util.Set;

import taf.te.util.TAFException;

public interface TAFExecInterface {
	public void init(TAFLogger logger, TAFServicesFactory tafSvc, InputData ipData) throws TAFException;
	public void getSupportedOperations(TAFLogger logger, TAFServicesFactory tafSvc, Map<String, Integer> operations) throws TAFException;
	public void getSupportedValidations(TAFLogger logger, TAFServicesFactory tafSvc, Set<String> validations) throws TAFException;
	public void execute(TAFLogger logger, TAFServicesFactory tafSvc, int operation, InputData ipData, OutputData opData, TCLocalData tclData) throws TAFException;
	public boolean validate(TAFLogger logger, TAFServicesFactory tafSvc, String operation, String validation, OutputData opData, TCLocalData tclData, List<String> validationMessages);
	public void windup(TAFLogger logger, TAFServicesFactory tafSvc) throws TAFException;
}

package taf.te.interfaces;

import java.io.PrintStream;

public interface TAFLogger {

	public void trace(String msg);
	public void debug(String msg);
	public void info(String msg);
	public void error(String msg);
	public void warn(String msg);
	public void fatal(String msg);
	public void error(Throwable ex);
	
	public PrintStream getPS();
}

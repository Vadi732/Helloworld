package taf.te.interfaces;

import taf.te.util.UTF8String;

public interface TAFJSONArrayR {
	public int getSize();
	public TAFJSONObjectR getObject(int idx);
	public TAFJSONArrayR getArray(int idx);
	public long getLongValue(int idx);
	public int getIntValue(int idx);
	public UTF8String getStrValue(int idx);
}

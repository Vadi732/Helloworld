package taf.te.interfaces;

import taf.te.util.UTF8String;

public interface OutputData {
	UTF8String getValue(String name);
	void putValue(String name, UTF8String value);
}

package taf.te.interfaces;

public interface TAFServicesFactory {
	TAFJSONFactory getJSONFactory();
	HttpCommunicator getHttpCommunicator();
}

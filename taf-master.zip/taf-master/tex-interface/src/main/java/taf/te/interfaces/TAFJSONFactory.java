package taf.te.interfaces;

import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public interface TAFJSONFactory {
	public TAFJSONObjectR parseJSON(UTF8String jsonData) throws TAFException;

	public TAFJSONObjectW createJSONObjectW() throws TAFException;
	public UTF8String buildJSON(TAFJSONObjectW jsonRoot) throws TAFException;
}

package taf.te.interfaces;

import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public interface TAFJSONArrayW {
	public TAFJSONObjectW addAndGetObject() throws TAFException;
	public TAFJSONArrayW addAndGetArray() throws TAFException;
	public void addIntValue(Integer val) throws TAFException;
	public void addStrValue(UTF8String val) throws TAFException;
}

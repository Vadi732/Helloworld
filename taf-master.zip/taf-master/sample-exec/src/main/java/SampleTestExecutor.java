import java.util.List;
import java.util.Map;
import java.util.Set;

import taf.te.interfaces.InputData;
import taf.te.interfaces.OutputData;
import taf.te.interfaces.TAFExecInterface;
import taf.te.interfaces.TAFLogger;
import taf.te.interfaces.TAFServicesFactory;
import taf.te.interfaces.TCLocalData;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public class SampleTestExecutor implements TAFExecInterface {

	public void init(TAFLogger logger, TAFServicesFactory tafSvc, InputData configParams) throws TAFException {
	}

	public void getSupportedOperations(TAFLogger logger, TAFServicesFactory tafSvc, Map<String, Integer> operations) throws TAFException {
		operations.put("AuthAPI", 1);
	}
	
	public void execute(TAFLogger logger, TAFServicesFactory tafSvc, int opID, InputData inputs, OutputData outputs, TCLocalData tclData)
			throws TAFException {
		if(opID == 1) {
			logger.debug("username: " + inputs.getValue("username"));
			logger.debug("password: " + inputs.getValue("password"));
			
			outputs.putValue("auth_token", new UTF8String("123456"));
			outputs.putValue("userid", new UTF8String("10"));
		}
	}

	public void windup(TAFLogger logger, TAFServicesFactory tafSvc) throws TAFException {
	}

	public void getSupportedValidations(TAFLogger logger, TAFServicesFactory tafSvc, Set<String> validations)
			throws TAFException {
	}

	public boolean validate(TAFLogger logger, TAFServicesFactory tafSvc, String operation, String validation,
			OutputData opData, TCLocalData tclData, List<String> validationMessages) {
		boolean bRes = false;
		return bRes;
	}
}

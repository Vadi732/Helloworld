package taf.util;

import java.io.StringReader;

import javax.json.Json;
import javax.json.JsonException;
import javax.json.JsonObject;
import javax.json.JsonReader;

import taf.te.interfaces.TAFJSONFactory;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFJSONObjectW;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public class TAFJSONFactoryImpl implements TAFJSONFactory {
	@Override
	public TAFJSONObjectR parseJSON(UTF8String jsonData) throws TAFException {
		JsonReader jReader = Json.createReader(new StringReader(jsonData.getUTF8String()));
		if(jReader == null) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON input is invalid!");
		}
		JsonObject jRootObj = null;
		try {
			jRootObj = jReader.readObject();
		} catch(JsonException | IllegalStateException jx) {
		}
		if(jRootObj == null) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON input is invalid!");
		}
		return new TAFJSONObjectImpl(jReader, jRootObj);
	}

	@Override
	public TAFJSONObjectW createJSONObjectW() throws TAFException {
		return new TAFJSONObjectImpl();
	}
	
	@Override
	public UTF8String buildJSON(TAFJSONObjectW jsonRoot) throws TAFException {
		TAFJSONObjectImpl jsonObjImpl = (TAFJSONObjectImpl)jsonRoot;
		jsonObjImpl.buildJSON(null, null);
		return new UTF8String(jsonObjImpl.generateJSONString());
	}
}

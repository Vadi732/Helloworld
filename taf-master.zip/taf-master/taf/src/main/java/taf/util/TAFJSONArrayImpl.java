package taf.util;

import java.util.ArrayList;

import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonString;

import taf.te.interfaces.TAFJSONArrayR;
import taf.te.interfaces.TAFJSONArrayW;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFJSONObjectW;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public class TAFJSONArrayImpl implements TAFJSONArrayR, TAFJSONArrayW {
	private static final int INVALID_VALUE = -111111; 
	JsonArray jArray = null;

	Object firstObj = null;
	List<Object> childValues = null;
	JsonArrayBuilder jThisArrayBuilder = null;

	public TAFJSONArrayImpl(JsonArray jArray) {
		this.jArray = jArray;
	}

	public TAFJSONArrayImpl() {
		childValues = new ArrayList<Object>();
	}

	private void buildChildren() {
		for (Object valObj : childValues) {
			if (valObj instanceof TAFJSONObjectImpl) {
				TAFJSONObjectImpl child = (TAFJSONObjectImpl) valObj;
				child.buildJSON(jThisArrayBuilder);
			} else if (valObj instanceof TAFJSONArrayImpl) {
				TAFJSONArrayImpl child = (TAFJSONArrayImpl) valObj;
				child.buildJSON(jThisArrayBuilder);
			} else if (valObj instanceof UTF8String) {
				UTF8String str = (UTF8String) valObj;
				jThisArrayBuilder.add(str.getUTF8String());
			} else if (valObj instanceof Integer) {
				Integer ival = (Integer) valObj;
				jThisArrayBuilder.add(ival);
			}
		}
	}

	public void buildJSON(String rname, JsonObjectBuilder jParentObjBuilder) {
		jThisArrayBuilder = Json.createArrayBuilder();
		buildChildren();
		if (jParentObjBuilder != null) {
			jParentObjBuilder.add(rname, jThisArrayBuilder);
		}
	}

	public void buildJSON(JsonArrayBuilder jParentArrayObjBuilder) {
		jThisArrayBuilder = Json.createArrayBuilder();
		buildChildren();
		if (jParentArrayObjBuilder != null) {
			jParentArrayObjBuilder.add(jThisArrayBuilder);
		}
	}

	@Override
	public int getSize() {
		if (jArray == null) {
			return 0;
		}
		return jArray.size();
	}

	@Override
	public TAFJSONObjectR getObject(int idx)  {
		TAFJSONObjectImpl obj = null;
		if (jArray != null) {
			try {
				JsonObject jObj = jArray.getJsonObject(idx);
				obj = new TAFJSONObjectImpl(null, jObj);
			} catch (IndexOutOfBoundsException ex) {
			} catch (ClassCastException ex) {
			}
		}

		return obj;
	}

	@Override
	public TAFJSONArrayR getArray(int idx) {
		TAFJSONArrayImpl jRet = null;
		if (jArray != null) {
			try {
				JsonArray jChildArray = jArray.getJsonArray(idx);
				jRet = new TAFJSONArrayImpl(jChildArray);
			} catch (IndexOutOfBoundsException ex) {
			} catch (ClassCastException ex) {
			}
		}
		return jRet;
	}

	@Override
	public long getLongValue(int idx) {
		long lval = INVALID_VALUE;
		if (jArray != null) {
			try {
				JsonNumber jNum = jArray.getJsonNumber(idx);
				lval = jNum.longValue(); 
			} catch (IndexOutOfBoundsException ex) {
			} catch (ClassCastException ex) {
			}
		}

		return lval;
	}

	@Override
	public int getIntValue(int idx) {
		Long val = getLongValue(idx);
		return val.intValue();
	}

	@Override
	public UTF8String getStrValue(int idx) {
		UTF8String sVal = null;
		if (jArray != null) {
			try {
				JsonString jStr = jArray.getJsonString(idx);
				sVal = new UTF8String(jStr.getString());
			} catch (IndexOutOfBoundsException ex) {
			} catch (ClassCastException ex) {
			}
		}

		return sVal;
	}

	@Override
	public TAFJSONObjectW addAndGetObject() throws TAFException {
		TAFJSONObjectW obj = null;
		if (firstObj == null) {
			obj = new TAFJSONObjectImpl();
			firstObj = obj;
			childValues.add(obj);
		} else if (firstObj instanceof TAFJSONObjectImpl) {
			obj = new TAFJSONObjectImpl();
			childValues.add(obj);
		} else {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching!");
		}
		return obj;
	}

	@Override
	public TAFJSONArrayW addAndGetArray() throws TAFException {
		TAFJSONArrayW array = new TAFJSONArrayImpl();
		if (firstObj == null) {
			firstObj = array;
			childValues.add(array);
		} else if (firstObj instanceof TAFJSONArrayImpl) {
			childValues.add(array);
		} else {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching!");
		}

		return array;
	}

	@Override
	public void addIntValue(Integer val) throws TAFException {
		if (firstObj == null) {
			firstObj = val;
			childValues.add(val);
		} else if (firstObj instanceof Integer) {
			childValues.add(val);
		} else {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching!");
		}
	}

	@Override
	public void addStrValue(UTF8String val) throws TAFException {
		if (firstObj == null) {
			firstObj = val;
			childValues.add(val);
		} else if (firstObj instanceof UTF8String) {
			childValues.add(val);
		} else {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching!");
		}
	}
}

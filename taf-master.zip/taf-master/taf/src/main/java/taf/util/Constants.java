package taf.util;

public class Constants {
	public static final int INVALID_JSON_INT = -99999;
	public static final long INVALID_JSON_LONG = -99999;
	public static final double INVALID_JSON_DOUBLE = -99999.99999;

	public static final int MAX_CUSTOM_MESSAGES_PER_OP = 10;
	
	public static final String TFI_INTERFACE_NAME = "taf.te.interfaces.TAFExecInterface";

	public static Excel.XLRow headerRow = loadHeaderRow();
	
	public static final String ROOT_PATH = "TAF_ROOT";
	public static final String CFG_PATH = "config";
	public static final String CFG_FILE_NAME = "tafconfig.json";
	public static final String TE_PATH = "test_executors";
	public static final String TS_PATH = "test_suites";
	public static final String DF_PATH = "data_files";
	public static final String FILES_PATH = "files";
	public static final String LOGS_PATH = "logs";

	public class JSON {
		public static final String PARAMETERS = "parameters";
		public static final String TEST_EXECUTORS = "test_executors";
		public static final String TEST_EXECUTOR_CONFIGS = "test_exec_configurations";
		public static final String TEST_SUITES_TO_EXECUTE = "test_suites_to_execute";
		
		public static final String NAME = "name";
		public static final String TEST_CASES = "test_cases";
		public static final String DATA_FILE_NAME = "data_file_name";
		public static final String INIT_OPERATIONS = "init_operations";
		public static final String INIT_DATA = "init_data";
		public static final String OPERATIONS = "operations";
		public static final String INPUTS = "inputs";
		public static final String VALIDATIONS = "validations";
		public static final String TYPE = "type";
		public static final String OUTPUT = "output";
		public static final String EXPECTED_OUTPUT = "expected_output";
		public static final String CONSTANTS = "constants";
		public static final String TEST_DATA = "test_data";
		public static final String CACHE = "cache";
	}

	public class XLPositions {
		public static final int RUN_ID = 0;
		public static final int TC_NAME = 1;
		public static final int OP_NAME = 2;
		public static final int TEST_RESULT = 3;
		public static final int VALIDATIONS_START = 4;
	}
	
	private static Excel.XLRow loadHeaderRow() {
		Excel.XLRow row = Excel.newXLRow();
		row.getCols().put(XLPositions.RUN_ID, "Run Number");
		row.getCols().put(XLPositions.TC_NAME, "TC Name");
		row.getCols().put(XLPositions.OP_NAME, "OP Name");
		row.getCols().put(XLPositions.TEST_RESULT, "Result");
		row.getCols().put(XLPositions.VALIDATIONS_START, "Validations");
		return row;
	}
}

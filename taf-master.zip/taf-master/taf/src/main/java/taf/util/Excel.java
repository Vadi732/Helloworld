package taf.util;

import java.io.ByteArrayInputStream;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;

public class Excel {
	private static Excel ex = new Excel();
	
	public static XLRow newXLRow() {
		return ex.new XLRow();
	}

	public static SheetRows newSheetRows() {
		return ex.new SheetRows();
	}
	
	public class SheetRows {
		public String sheetName;
		public List<XLRow> rows;
		
		public SheetRows() {
			rows = new ArrayList<XLRow>();
		}
	}
	
	public class XLRow {
		private int rowNum;
		private Map<Integer, String> cols;

		public XLRow() {
			cols = new HashMap<Integer, String>();
		}

		public int getRowNum() {
			return rowNum;
		}

		public void setRowNum(int rowNum) {
			this.rowNum = rowNum;
		}

		public Map<Integer, String> getCols() {
			return cols;
		}

		public boolean isEmpty() {
			boolean bEmpty = true;
			Iterator<Map.Entry<Integer, String>> it = cols.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry<Integer, String> pair = it.next();
				if (pair.getValue() != null && !pair.getValue().isEmpty()) {
					bEmpty = false;
					break;
				}
			}
			return bEmpty;
		}
	}

	private String getStrValue(Cell cell) {
		String str = "";
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			str = cell.getStringCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:
			Double db = new Double(cell.getNumericCellValue());
			int iv = db.intValue();
			if (db == iv) {
				str = iv + "";
			} else {
				str = db.toString();
			}
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			Boolean b = new Boolean(cell.getBooleanCellValue());
			str = b.toString();
			break;
		// case Cell.CELL_TYPE_FORMULA:
		// str = getStrValue(cell.getCachedFormulaResultType(), cell);
		// break;
		default:
		}
		return Util.trimAdvanced(str);
	}

	public void processActiveSheet(TAFLogger logger, byte[] fileContents, List<Excel.XLRow> rows, final String fn)
			throws TAFException {
		ByteArrayInputStream bis = null;
		XSSFWorkbook myWorkBook = null;
		try {
			bis = new ByteArrayInputStream(fileContents);
			myWorkBook = new XSSFWorkbook(bis);

			for (Row row : myWorkBook.getSheetAt(0)) {
				Excel.XLRow xlRow = new Excel.XLRow();
				xlRow.setRowNum(row.getRowNum());
				Map<Integer, String> cols = xlRow.getCols();

				for (Cell cell : row) {
					String colVal = getStrValue(cell);
					cols.put(cell.getColumnIndex(), colVal);
				}
				rows.add(xlRow);
			}

		} catch (Exception ex) {
			logger.error(ex);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, fn + " - " + ex.getMessage());
		} finally {
			try {
				if (myWorkBook != null) {
					myWorkBook.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (Exception ex) {
				logger.error(ex);
			}
		}
	}

	public void processSheets(TAFLogger logger, byte[] fileContents, Map<String, List<Excel.XLRow>> sheetNameToRowsMap,
			List<String> sheetsName) throws TAFException {
		ByteArrayInputStream bis = null;
		XSSFWorkbook myWorkBook = null;
		try {
			bis = new ByteArrayInputStream(fileContents);
			myWorkBook = new XSSFWorkbook(bis);
			List<XSSFSheet> sheets = new ArrayList<XSSFSheet>();

			for (String sheetName : sheetsName) {
				sheets.add(myWorkBook.getSheet(sheetName));
			}

			processSheets(sheets, sheetNameToRowsMap);
		} catch (Exception ex) {
			logger.error(ex);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, ex.getMessage());
		} finally {
			try {
				if (myWorkBook != null) {
					myWorkBook.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (Exception ex) {
				logger.error(ex);
			}
		}
	}

	public void processAllSheets(TAFLogger logger, byte[] fileContents, Map<String, List<Excel.XLRow>> sheetNameToRowsMap,
			final String fn) throws TAFException {
		ByteArrayInputStream bis = null;
		XSSFWorkbook myWorkBook = null;
		try {
			bis = new ByteArrayInputStream(fileContents);
			myWorkBook = new XSSFWorkbook(bis);
			List<XSSFSheet> sheets = new ArrayList<XSSFSheet>();

			for (int i = 0; i < myWorkBook.getNumberOfSheets(); i++) {
				sheets.add(myWorkBook.getSheetAt(i));

			}
			processSheets(sheets, sheetNameToRowsMap);

		} catch (Exception ex) {
			logger.error(ex);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, fn + " - " + ex.getMessage());
		} finally {
			try {
				if (myWorkBook != null) {
					myWorkBook.close();
				}
				if (bis != null) {
					bis.close();
				}
			} catch (Exception ex) {
				logger.error(ex);
			}
		}
	}

	private void processSheets(List<XSSFSheet> sheets, Map<String, List<XLRow>> sheetNameToRowsMap) {
		for (XSSFSheet sheet : sheets) {
			List<Excel.XLRow> rows = new ArrayList<Excel.XLRow>();
			for (Row row : sheet) {
				Excel.XLRow xlRow = new Excel.XLRow();
				xlRow.setRowNum(row.getRowNum());
				Map<Integer, String> cols = xlRow.getCols();
				rows.add(xlRow);

				for (Cell cell : row) {
					String colVal = getStrValue(cell);
					cols.put(cell.getColumnIndex(), colVal);
				}
			}
			sheetNameToRowsMap.put(sheet.getSheetName(), rows);
		}

	}

	public byte[] writeToXLBytes(TAFLogger logger, List<Excel.XLRow> rows) throws taf.te.util.TAFException, IOException {
		String sheetName = "Rows";
		XSSFWorkbook wb = new XSSFWorkbook();

		createSheet(logger, sheetName, wb, rows);
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();

		wb.write(byteOut);
		byteOut.flush();
		
		byte[] bytes = byteOut.toByteArray();
		byteOut.close();
		wb.close();
		return bytes;
	}

	public byte[] writeToXLBytes(TAFLogger logger, Map<String, SheetRows> nameSheetMap) throws taf.te.util.TAFException, IOException {
		XSSFWorkbook wb = new XSSFWorkbook();

		for(Map.Entry<String, SheetRows> pair : nameSheetMap.entrySet()) {
			SheetRows sr = pair.getValue();
			createSheet(logger, sr.sheetName, wb, sr.rows);
		}
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();

		wb.write(byteOut);
		byteOut.flush();
		
		byte[] bytes = byteOut.toByteArray();
		byteOut.close();
		wb.close();
		return bytes;
	}
	
	public void writeToXLFile(TAFLogger logger, List<Excel.XLRow> rows, final String fn) throws taf.te.util.TAFException, IOException {
		byte[] xlBytes = writeToXLBytes(logger, rows);		
		FileOutputStream fileOut = new FileOutputStream(fn);

		fileOut.write(xlBytes);
		fileOut.flush();
		fileOut.close();
	}

	private void createSheet(TAFLogger logger, String sheetName, XSSFWorkbook wb, List<XLRow> rows) {
		XSSFSheet sheet = wb.createSheet(sheetName);

		// iterating r number of rows
		for (int idx = 0; idx < rows.size(); idx++) {
			Excel.XLRow row = rows.get(idx);
			Row xlrow = sheet.createRow(idx);
			for (Map.Entry<Integer, String> pair : row.getCols().entrySet()) {
				Cell cell = xlrow.createCell(pair.getKey());
				cell.setCellValue(pair.getValue());
			}
		}
	}
}

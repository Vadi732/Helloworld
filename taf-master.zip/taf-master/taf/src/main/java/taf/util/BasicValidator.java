package taf.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import taf.IOPDataImpl;
import taf.DataDefinitions.VALIDATION_DATA_TYPE;
import taf.DataDefinitions.VALIDATION_TYPE;
import taf.te.interfaces.TAFExecInterface;
import taf.te.interfaces.TAFLogger;
import taf.te.interfaces.TAFServicesFactory;
import taf.te.interfaces.TCLocalData;
import taf.te.util.UTF8String;

public class BasicValidator {
	private VALIDATION_TYPE vt;
	private VALIDATION_DATA_TYPE vdt;
	private String varName;
	private UTF8String var;
	private String matchName;
	private UTF8String match;
	private String message;
	private boolean bSuccess = false;
	
	public BasicValidator(VALIDATION_TYPE vt, VALIDATION_DATA_TYPE vdt) {
		this.vt = vt;
		this.vdt = vdt;
	}
	
	public void setVarData(String varName, UTF8String var) {
		this.varName = varName;
		this.var = var;
	}
	
	public void setMatchData(String matchName, UTF8String match) {
		this.matchName = matchName;
		this.match = match;
	}

	public VALIDATION_TYPE getValidationType() {
		return vt;
	}
	
	public VALIDATION_DATA_TYPE getValidationDataType() {
		return vdt;
	}
	
	public String getMessage() {
		return message;
	}
	public String toString() {
		return (vt.getName() + "-" + vdt.getName() + ":" + varName + "["+ var + "] " + matchName + "["+ match + "]");
	}
	public boolean isSuccess() {
		return bSuccess;
	}
	public void validate() {
		if(vt == VALIDATION_TYPE.CUSTOM) return;
		
		switch(vdt) {
		case STRING:
			bSuccess = performStrOps();
			break;
		case INT:
			bSuccess = performIntOps();
			break;
		case DOUBLE:
			bSuccess = performDoubleOps();
			break;
		case STR_SET:
			bSuccess = performStringSetOps();
			break;
		default:
			break;
		}
		constructMessage(bSuccess);
	}

	public void validateCustom(TAFLogger logger, TAFServicesFactory tafSvc, TAFExecInterface tafi, String operation, 
			String validation, Map<String, UTF8String> cache, IOPDataImpl outputs, TCLocalData tclData) {
		if(vt != VALIDATION_TYPE.CUSTOM) return;
		
		List<String> validationMessages = new ArrayList<String>();
		bSuccess = tafi.validate(logger, tafSvc, operation, validation, outputs, tclData, validationMessages);
		
		StringBuffer sb = new StringBuffer();
		int max = (validationMessages.size() > Constants.MAX_CUSTOM_MESSAGES_PER_OP ? Constants.MAX_CUSTOM_MESSAGES_PER_OP : validationMessages.size());
		for(int idx = 0; idx < max; idx++) {
			sb.append(validationMessages.get(idx));
			sb.append(System.lineSeparator());
		}
		message = sb.toString();
	}
	
	private boolean performStrOps() {
		boolean bRes = false;
		switch(vt) {
		case EQUAL_CS:
			bRes = compareStr(false);
			break;
		case EQUAL_CIS:
			bRes = compareStr(true);
			break;
		case EMPTY:
			bRes = (var == null || var.isEmpty());
		case NOT_EMPTY:
			bRes = (var != null && !var.isEmpty());
		default:
			break;
		}
		return bRes;
	}
	
	private boolean performIntOps() {
		boolean bRes = false;
		switch(vt) {
		case EQUAL_CS:
		case EQUAL_CIS:
			bRes = compareInt();
			break;
		default:
			break;
		}
		return bRes;
	}
	
	private boolean performDoubleOps() {
		boolean bRes = false;
		switch(vt) {
		case EQUAL_CS:
		case EQUAL_CIS:
			bRes = compareDouble();
			break;
		default:
			break;
		}
		return bRes;
	}
	
	private boolean performStringSetOps() {
		boolean bRes = false;
		switch(vt) {
		case CONTAINS:
			Set<String> varSet = createSet(var);
			Set<String> matchSet = createSet(match);
			bRes = varSet.containsAll(matchSet);
			break;
		default:
			break;
		}
		return bRes;
	}
	
	private boolean compareInt() {
		if(var != null && match != null) {
			int ivar = Integer.parseInt(var.getUTF8String());
			int imatch = Integer.parseInt(match.getUTF8String());
			return (ivar == imatch);
		}
		return false;
	}

	private boolean compareDouble() {
		if(var != null && match != null) {
			double ivar = Double.parseDouble(var.getUTF8String());
			double imatch = Double.parseDouble(match.getUTF8String());
			return (ivar == imatch);
		}
		return false;
	}
	
	private boolean compareStr(boolean bCIS) {
		if(var != null && match != null) {
			if(bCIS) {
				return var.getUTF8String().equalsIgnoreCase(match.getUTF8String());
			}
			return var.getUTF8String().equals(match.getUTF8String());
		}
		return false;
	}

	private Set<String> createSet(UTF8String commaSepStr) {
		Set<String> set = new HashSet<String>();
		if(commaSepStr != null && !commaSepStr.isEmpty()) {
			String[] vals = commaSepStr.getUTF8String().split(",");
			for(int idx = 0; idx < vals.length; idx++) {
				set.add(vals[idx]);
			}
		}
		return set;
	}
	
	private void constructMessage(boolean bRes) {
		message = (vt.getName() + "-" + vdt.getName() + ":" + varName + "["+ var + "] " + matchName + "["+ match + "]") + (bRes ? " SUCCESS" : " FAILURE");
	}
}

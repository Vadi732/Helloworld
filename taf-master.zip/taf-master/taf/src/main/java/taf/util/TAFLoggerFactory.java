package taf.util;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

import taf.te.interfaces.TAFLogger;

public class TAFLoggerFactory {
	private static TAFLoggerFactory blf = new TAFLoggerFactory();
	private static FileCfgHandler fch = null;
	
	private final static String pattern = "%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p %c{1}:%L - %m%n";

	private final static int DEFAULT_MAX_FILE_SIZE = 1048576; // 1MB
	private final static int DEFAULT_MAX_ROLLING_IDX = 1000;
	private final static int DEFAULT_LOG_LEVEL = 4;

	public static String LOG_MAX_FILE_SIZE_PNAME = "logging.maxFileSize";
	public static String LOG_MAX_ROLLING_IDX_PNAME = "logging.maxRollingIdx";
	public static String LOG_LEVEL = "logging.level";
	
	public static TAFLogger create(String context) {
		return blf.new TAFLoggerImpl(context);
	}

	public static void init(String rootPath, FileCfgHandler ifch) {
		fch = ifch;
		String logFP = rootPath + File.separator + Constants.LOGS_PATH + File.separator + "taf.log";

		Logger.getRootLogger().getLoggerRepository().resetConfiguration();
		int maxFileSize = fch.getCfgParamInt(LOG_MAX_FILE_SIZE_PNAME);
		if (maxFileSize <= 0) {
			maxFileSize = DEFAULT_MAX_FILE_SIZE;
		}

		int maxRollingIdx = fch.getCfgParamInt(LOG_MAX_ROLLING_IDX_PNAME);
		if (maxRollingIdx <= 0) {
			maxRollingIdx = DEFAULT_MAX_ROLLING_IDX;
		}

		Level ll = getLoglevel(fch);
		RollingFileAppender fa = new RollingFileAppender();
		fa.setName("org.taf");
		fa.setFile(logFP);
		fa.setLayout(new PatternLayout(pattern));
		fa.setThreshold(ll);
		fa.setAppend(true);
		fa.setMaximumFileSize(maxFileSize);
		fa.setMaxBackupIndex(maxRollingIdx);
		fa.activateOptions();
		// add appender to any Logger (here is root)
		Logger.getRootLogger().addAppender(fa);
		Logger.getLogger("init").info("Initializing TAF");
	}

	private static Level getLoglevel(FileCfgHandler fch) {
		int lvl = fch.getCfgParamInt(LOG_LEVEL);
		if (lvl < 0) {
			lvl = DEFAULT_LOG_LEVEL;
		}
		
		Level ll = Level.DEBUG;
		switch (lvl) {
		case 0:
			ll = Level.FATAL;
			break;
		case 1:
			ll = Level.WARN;
			break;
		case 2:
			ll = Level.ERROR;
			break;
		case 3:
			ll = Level.INFO;
			break;
		case 4:
			ll = Level.DEBUG;
			break;
		default:
			ll = Level.DEBUG;
			break;
		}
		return ll;
	}
	
	private class TAFLoggerImpl implements TAFLogger {
		Logger logger = null;
		LogStream ls = null;

		TAFLoggerImpl(String context) {
			String fc = Thread.currentThread().getId() + ":" + context + ":";
			logger = Logger.getLogger(fc);
			ls = new LogStream(logger);
		}

		public void trace(String msg) {
			logger.trace(msg);
		}

		public void debug(String msg) {
			logger.debug(msg);
		}

		public void info(String msg) {
			logger.info(msg);
		}

		public void error(String msg) {
			logger.error(msg);
		}

		public void error(Throwable ex) {
			logger.error("ERROR:", ex);
		}

		public void warn(String msg) {
			logger.warn(msg);
		}

		public void fatal(String msg) {
			logger.fatal(msg);
		}

		public PrintStream getPS() {
			return new PrintStream(ls);
		}
	}

	public class LogStream extends FilterOutputStream {
		private Logger logger = null;
		private ByteArrayOutputStream bos = new ByteArrayOutputStream();

		public LogStream(Logger logger) {
			super(null);
			super.out = bos;
			this.logger = logger;
		}

		@Override
		public void flush() throws IOException {
			// this was never called in my test
			bos.flush();
			if (bos.size() > 0) {
				logger.info(bos.toString());
			}
			bos.reset();
		}

		@Override
		public void write(byte[] b) throws IOException {
			logger.info(new String(b));
		}

		@Override
		public void write(byte[] b, int off, int len) throws IOException {
			logger.info(new String(b, off, len));
		}

		@Override
		public void write(int b) throws IOException {
			write(new byte[] { (byte) b });
		}
	}
}

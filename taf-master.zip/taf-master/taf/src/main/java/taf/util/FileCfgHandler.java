package taf.util;

import java.util.HashMap;

import java.util.Map;
import java.util.Set;

import taf.te.interfaces.TAFJSONObjectR;

public class FileCfgHandler {
	private Map<String, String> kvMap = null;
	
	public int getCfgParamInt(String pn) {
		int pv = -1;
		try {
			String pvs = kvMap.get(pn);
			if(pvs != null) {
				pv = Integer.parseInt(pvs);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return pv;
	}

	public String getCfgParamStr(String pn) {
		String pvs = "";
		try {
			pvs = (String)kvMap.get(pn);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return pvs;
	}
	
	public void loadPropertiesFile(TAFJSONObjectR jParamRoot) {
		kvMap = new HashMap<String, String>(); 
		Set<String> keys = jParamRoot.getKeys();
		for(String key : keys) {
			TAFJSONObjectR jObject = jParamRoot.getMandatoryObject(key);
			if(jObject != null) {
				parseJSONObject(key, jObject, kvMap);
			}
		}
	}
	
	private void parseJSONObject(String pfx, TAFJSONObjectR jObj, Map<String, String> kvMap) {
		Set<String> keys = jObj.getKeys();
		for(String key : keys) {
			String prefix = (pfx.isEmpty() ? "" : pfx + ".") + key;
			String sVal = jObj.getOptionalStrValue(key, "").getUTF8String();
			if(sVal != null) {
				kvMap.put(prefix, sVal);
			}
		}
	}
}

package taf.util;

import java.util.HashMap;


import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonException;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonString;

import taf.te.interfaces.TAFJSONArrayR;
import taf.te.interfaces.TAFJSONArrayW;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFJSONObjectW;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;


public class TAFJSONObjectImpl implements TAFJSONObjectR, TAFJSONObjectW {
	private static final int INVALID_VALUE = -111111; 
	JsonReader jReader = null;
	JsonObject jRootObj = null;
	
	JsonObjectBuilder jThisObjBuilder = null;
	Map<String, Object> childValues = null;
	
	public TAFJSONObjectImpl() {
		childValues = new HashMap<String, Object>();
	}
	
	public TAFJSONObjectImpl(JsonReader jReader, JsonObject jRootObj) {
		this.jReader = jReader;
		this.jRootObj = jRootObj;
	}

	private void buildChildren() {
		for(Map.Entry<String, Object> pair : childValues.entrySet()) {
			String name = pair.getKey();
			Object valObj = pair.getValue();
			if(valObj instanceof TAFJSONObjectImpl) {
				TAFJSONObjectImpl child = (TAFJSONObjectImpl)valObj;
				child.buildJSON(name, jThisObjBuilder);
			} else if(valObj instanceof TAFJSONArrayImpl) {
				TAFJSONArrayImpl child = (TAFJSONArrayImpl)valObj;
				child.buildJSON(name, jThisObjBuilder);
			} else if(valObj instanceof UTF8String) {
				UTF8String str = (UTF8String)valObj;
				jThisObjBuilder.add(name, str.getUTF8String());
			} else if(valObj instanceof Integer) {
				Integer ival = (Integer)valObj;
				jThisObjBuilder.add(name, ival);
			} else if(valObj instanceof Long) {
				Long lval = (Long)valObj;
				jThisObjBuilder.add(name, lval);
			} else if(valObj instanceof Double) {
				Double dval = (Double)valObj;
				jThisObjBuilder.add(name, dval);
			}
		}
	}
	
	public void buildJSON(String rname, JsonObjectBuilder jParentObjBuilder) {
		jThisObjBuilder = Json.createObjectBuilder();
		buildChildren();
		if(jParentObjBuilder != null) {
			jParentObjBuilder.add(rname, jThisObjBuilder);
		}
	}
	
	public void buildJSON(JsonArrayBuilder jParentArrayObjBuilder) {
		jThisObjBuilder = Json.createObjectBuilder();
		buildChildren();
		if(jParentArrayObjBuilder != null) {
			jParentArrayObjBuilder.add(jThisObjBuilder);
		}
	}
	
	public String generateJSONString() {
		JsonObject jObj = jThisObjBuilder.build();
		return jObj.toString();
	}
	
	public void closeReader() throws TAFException {
		try {
			if(jReader != null) { 
				jReader.close();
			}
		} catch(JsonException ex) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, ex.getMessage());
		}
	}
	
	@Override
	public Set<String> getKeys() {
		Set<String> keys = new HashSet<String>();
		if(childValues != null) {
			keys.addAll(childValues.keySet());
		} else if(jRootObj != null) {
			keys.addAll(jRootObj.keySet());
		}
		
		return keys;
	}
	
	@Override
	public TAFJSONObjectR getMandatoryObject(String name) {
		TAFJSONObjectImpl obj = null;
		if(jRootObj != null) {
			JsonObject jObj = jRootObj.getJsonObject(name);
			if(jObj != null) {
				obj = new TAFJSONObjectImpl(null, jObj);
			}
		}
		return obj;
	}

	@Override
	public TAFJSONArrayR getMandatoryArray(String name) {
		TAFJSONArrayImpl array = null;
		if(jRootObj != null) {
			JsonArray jArray = jRootObj.getJsonArray(name);
			if(jArray != null) {
				array = new TAFJSONArrayImpl(jArray);
			}
		}
		return array;
	}

	@Override
	public long getMandatoryLongValue(String name) {
		long val = INVALID_VALUE;
		if(jRootObj != null) {
			JsonNumber jsonNum = null;
			try {
				jsonNum = jRootObj.getJsonNumber(name);
				if(jsonNum != null) {
					val = jsonNum.longValue();
				}
			} catch(ClassCastException ex) {
			}
		}
		return val;
	}
	
	@Override
	public int getMandatoryIntValue(String name) {
		Long val = getMandatoryLongValue(name);
		return val.intValue();
	}
	
	@Override
	public UTF8String getMandatoryStrValue(String name) {
		UTF8String sVal = null;
		if(jRootObj != null) {
			JsonString jsonStr = null;
			try {
				jsonStr = jRootObj.getJsonString(name);
				if(jsonStr != null && jsonStr.getString() != null) {
					sVal = new UTF8String(jsonStr.getString().stripLeading().stripTrailing());
				}
			} catch(ClassCastException ex) {
			}
		}
		return sVal;
	}

	//Writer objects
	@Override
	public TAFJSONObjectW addAndGetObject(String name) throws TAFException {
		TAFJSONObjectImpl childObj = null;

		if(childValues.containsKey(name)) {
			Object obj = childValues.get(name);
			if(obj instanceof TAFJSONObjectImpl) {
				childObj = (TAFJSONObjectImpl)obj;
			} else {
				throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching! Name: " + name);
			}
		} else {
			childObj = new TAFJSONObjectImpl();
			childValues.put(name, childObj);
		}

		return childObj;
	}

	@Override
	public TAFJSONArrayW addAndGetArray(String name) throws TAFException {
		TAFJSONArrayImpl childArray = null;

		if(childValues.containsKey(name)) {
			Object obj = childValues.get(name);
			if(obj instanceof TAFJSONArrayImpl) {
				childArray = (TAFJSONArrayImpl)obj;
			} else {
				throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field type is not matching! Name: " + name);
			}
		} else {
			childArray = new TAFJSONArrayImpl();
			childValues.put(name, childArray);
		}

		return childArray;
	}

	@Override
	public void addIntValue(String name, Integer val) throws TAFException {
		if(childValues.containsKey(name)) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field is dupilcate! Name: " + name);
		} else {
			childValues.put(name, val);
		}
	}

	@Override
	public void addStrValue(String name, UTF8String val) throws TAFException {
		if(childValues.containsKey(name)) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field is dupilcate! Name: " + name);
		} else {
			childValues.put(name, val);
		}
	}

	@Override
	public TAFJSONObjectR getOptionalObject(String name) {
		return getMandatoryObject(name);
	}

	@Override
	public TAFJSONArrayR getOptionalArray(String name) {
		return getMandatoryArray(name);
	}

	@Override
	public long getOptionalLongValue(String name, long defVal) {
		long ret = getMandatoryLongValue(name);
		if(ret == INVALID_VALUE) {
			ret = defVal;
		}
		return ret;
	}
	
	@Override
	public int getOptionalIntValue(String name, int defVal) {
		int ret = getMandatoryIntValue(name);
		if(ret == INVALID_VALUE) {
			ret = defVal;
		}
		return ret;
	}

	@Override
	public UTF8String getOptionalStrValue(String name, String defVal) {
		UTF8String ret = getMandatoryStrValue(name);
		if(ret == null) {
			ret = new UTF8String(defVal);
		}
		return ret;
	}

	@Override
	public void addLongValue(String name, Long val) throws TAFException {
		if(childValues.containsKey(name)) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field is dupilcate! Name: " + name);
		} else {
			childValues.put(name, val);
		}
	}

	@Override
	public void addDoubleValue(String name, Double val) throws TAFException {
		if(childValues.containsKey(name)) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "JSON field is dupilcate! Name: " + name);
		} else {
			childValues.put(name, val);
		}
	}

}

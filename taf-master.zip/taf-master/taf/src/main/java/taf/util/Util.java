package taf.util;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import taf.DataDefinitions;
import taf.DataDefinitions.FIELD_OP_TYPE;
import taf.DataDefinitions.InputField;
import taf.DataDefinitions.Operation;
import taf.DataDefinitions.Variable;
import taf.DataDefinitions.VALIDATION_DATA_TYPE;
import taf.DataDefinitions.VALIDATION_TYPE;
import taf.IOPDataImpl;
import taf.te.interfaces.TAFJSONArrayR;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public class Util {

	public static void loadTestExecutorClassNames(TAFLogger logger, TAFJSONObjectR jCfgRoot,
			Set<String> executorClassNames) throws TAFException {
		TAFJSONArrayR jTestExecutors = jCfgRoot.getMandatoryArray(Constants.JSON.TEST_EXECUTORS);
		for (int idx = 0; idx < jTestExecutors.getSize(); idx++) {
			executorClassNames.add(jTestExecutors.getStrValue(idx).getUTF8String());
		}

		if (executorClassNames.isEmpty()) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS,
					"Could not read any executors from " + Constants.JSON.TEST_EXECUTORS);
		}
	}

	public static void loadDataFiles(TAFLogger logger, String rootPath,
			Map<String, DataDefinitions.DataFile> dataFilesMap) throws TAFException {
		String dfPath = rootPath + File.separator + Constants.DF_PATH;
		boolean bError = false;
		TAFJSONFactoryImpl jFactory = new TAFJSONFactoryImpl();
		File folder = new File(dfPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				String path = file.getAbsolutePath();
				try {
					String fileContents = file2String(logger, path);
					TAFJSONObjectR jTSRoot = jFactory.parseJSON(new UTF8String(fileContents));
					
					DataDefinitions.DataFile dataFile = DataDefinitions.ddefs.new DataFile();
					dataFile.name = jTSRoot.getMandatoryStrValue(Constants.JSON.NAME).getUTF8String();

					TAFJSONObjectR jInitData = jTSRoot.getMandatoryObject(Constants.JSON.INIT_DATA);
					dataFile.initData = new HashMap<String, UTF8String>();
					readJSONObjectIntoStrMap(logger, jInitData, dataFile.initData);

					TAFJSONArrayR jTestData = jTSRoot.getMandatoryArray(Constants.JSON.TEST_DATA);
					dataFile.data = new ArrayList<Map<String, UTF8String>>();
					for (int idx = 0; idx < jTestData.getSize(); idx++) {
						TAFJSONObjectR jData = jTestData.getObject(idx);
						Map<String, UTF8String> td = new HashMap<String, UTF8String>();
						readJSONObjectIntoStrMap(logger, jData, td);
						dataFile.data.add(td);
					}
					
					TAFJSONObjectR jConstants = jTSRoot.getMandatoryObject(Constants.JSON.CONSTANTS);
					dataFile.constants = new HashMap<String, UTF8String>();
					if(jConstants != null && !jConstants.getKeys().isEmpty()) {
						for(String key : jConstants.getKeys()) {
							dataFile.constants.put(key, jConstants.getOptionalStrValue(key, ""));
						}
					}
					
					dataFilesMap.put(dataFile.name, dataFile);
				} catch (TAFException e) {
					logger.error("Data file " + path + " could not be read");
					logger.error(e);
					bError = true;
				}
			}
		}

		if (bError) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Some of the test suites could not be loaded");
		}
	}

	public static void loadTestSuites(TAFLogger logger, TAFJSONFactoryImpl jFactory, String rootPath,
			Set<String> testSuites2Load, List<DataDefinitions.TestSuite> testSuites, Set<String> reqdOps,
			Set<String> reqdCustomValidations, Map<String, Integer> opName2IdMap) throws TAFException {
		String tsPath = rootPath + File.separator + Constants.TS_PATH;
		boolean bError = false;

		File folder = new File(tsPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				String path = file.getAbsolutePath();
				try {
					String fileContents = file2String(logger, path);
					TAFJSONObjectR jTSRoot = jFactory.parseJSON(new UTF8String(fileContents));

					String name = jTSRoot.getMandatoryStrValue(Constants.JSON.NAME).getUTF8String();
					if (!testSuites2Load.contains(name)) {
						logger.info("Test suite: " + name + " is not configured for execution, skipping it!");
						continue;
					}

					DataDefinitions.TestSuite ts = readTSContent(logger, jTSRoot, reqdOps, reqdCustomValidations,
							opName2IdMap);
					testSuites.add(ts);
				} catch (TAFException e) {
					logger.error("Test suite " + path + " could not be read");
					logger.error(e);
					bError = true;
				}
			}
		}

		if (bError) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Some of the test suites could not be loaded");
		}
	}

	public static DataDefinitions.TestSuite readTSContent(TAFLogger logger, TAFJSONObjectR jTSRoot, Set<String> reqdOps,
			Set<String> reqdCustomValidations, Map<String, Integer> opName2IdMap) throws TAFException {
		DataDefinitions.TestSuite ts = DataDefinitions.ddefs.new TestSuite();

		ts.name = jTSRoot.getMandatoryStrValue(Constants.JSON.NAME).getUTF8String();
		ts.dfName = jTSRoot.getMandatoryStrValue(Constants.JSON.DATA_FILE_NAME).getUTF8String();

		TAFJSONArrayR jInitOps = jTSRoot.getMandatoryArray(Constants.JSON.INIT_OPERATIONS);
		if (jInitOps != null && jInitOps.getSize() > 0) {
			ts.initOps = new ArrayList<Operation>();
			readOperations(logger, jInitOps, ts.initOps, reqdOps, reqdCustomValidations, opName2IdMap);
		}

		TAFJSONArrayR jTCs = jTSRoot.getMandatoryArray(Constants.JSON.TEST_CASES);
		ts.testCases = new ArrayList<DataDefinitions.TestCase>();
		readTestCases(logger, jTCs, ts.testCases, reqdOps, reqdCustomValidations, opName2IdMap);
		return ts;
	}

	public static void readJSONArrayIntoStringCollection(TAFLogger logger, TAFJSONArrayR jArray,
			Collection<String> collection) {
		if (jArray == null)
			return;

		for (int idx = 0; idx < jArray.getSize(); idx++) {
			String val = jArray.getStrValue(idx).getUTF8String();
			collection.add(val);
		}
	}

	private static void readTestCases(TAFLogger logger, TAFJSONArrayR jTCs, List<DataDefinitions.TestCase> testCases,
			Set<String> reqdOps, Set<String> reqdCustomValidations, Map<String, Integer> opName2IdMap)
			throws TAFException {
		for (int idx = 0; idx < jTCs.getSize(); idx++) {
			TAFJSONObjectR jTC = jTCs.getObject(idx);

			DataDefinitions.TestCase tc = DataDefinitions.ddefs.new TestCase();
			testCases.add(tc);

			tc.name = jTC.getMandatoryStrValue(Constants.JSON.NAME).getUTF8String();
			TAFJSONArrayR jOPs = jTC.getMandatoryArray(Constants.JSON.OPERATIONS);
			tc.operations = new ArrayList<DataDefinitions.Operation>();
			readOperations(logger, jOPs, tc.operations, reqdOps, reqdCustomValidations, opName2IdMap);
		}
	}

	private static void readOperations(TAFLogger logger, TAFJSONArrayR jOPs, List<DataDefinitions.Operation> operations,
			Set<String> reqdOps, Set<String> reqdCustomValidations, Map<String, Integer> opName2IdMap)
			throws TAFException {
		for (int idx = 0; idx < jOPs.getSize(); idx++) {
			TAFJSONObjectR jOP = jOPs.getObject(idx);

			DataDefinitions.Operation op = DataDefinitions.ddefs.new Operation();
			operations.add(op);

			op.name = jOP.getMandatoryStrValue(Constants.JSON.NAME).getUTF8String().toLowerCase();
			if (!opName2IdMap.containsKey(op.name)) {
				throw new TAFException(ProcessingCode.INVALID_CONTENTS,
						"TestSuite is invalid, operation is not supported " + op.name);
			}
			op.id = opName2IdMap.get(op.name);
			//op.inputs = new HashMap<String, Variable>();
			op.inputs = new HashMap<String, InputField>();
			reqdOps.add(op.name);

			TAFJSONObjectR jInputs = jOP.getMandatoryObject(Constants.JSON.INPUTS);
			readInputParameters(logger, jInputs, op.inputs);

			op.validations = new ArrayList<DataDefinitions.Validation>();

			TAFJSONObjectR jOPValidations = jOP.getMandatoryObject(Constants.JSON.VALIDATIONS);
			readOPValidations(logger, jOPValidations, op.validations, reqdCustomValidations);

			TAFJSONObjectR jCacheElems = jOP.getMandatoryObject(Constants.JSON.CACHE);
			if (jCacheElems != null) {
				op.cache = new HashMap<String, Variable>();
				readJSONObjectIntoParameters(logger, jCacheElems, op.cache);
			}
		}
	}

	private static void readJSONObjectIntoParameters(TAFLogger logger, TAFJSONObjectR jObj,
			Map<String, Variable> fields) {
		if (jObj == null)
			return;

		Set<String> jKeys = jObj.getKeys();
		for (String name : jKeys) {
			UTF8String value = jObj.getMandatoryStrValue(name);
			DataDefinitions.Variable param = DataDefinitions.ddefs.new Variable(value);
			fields.put(name, param);
		}
	}
	
	private static void readInputParameters(TAFLogger logger, TAFJSONObjectR jObj,
			Map<String, InputField> ipFields) {
		if (jObj == null)
			return;

		Set<String> jKeys = jObj.getKeys();
		for (String name : jKeys) {
			InputField ipField = null;
			if(name.equalsIgnoreCase(FIELD_OP_TYPE.CONCAT.getName())) {
				TAFJSONArrayR jArray = jObj.getMandatoryArray(name);
				for(int idx = 0; idx < jArray.getSize(); idx++) {
					ipField = DataDefinitions.ddefs.new InputField(FIELD_OP_TYPE.CONCAT, null, jArray.getObject(idx));	
					ipFields.put(ipField.getName(), ipField);
				}
			} else {
				ipField = DataDefinitions.ddefs.new InputField(FIELD_OP_TYPE.BASIC_RESOLUTION, name, jObj);	
				ipFields.put(name, ipField);
			}
		}
	}
	
	private static void readJSONObjectIntoIOPData(TAFLogger logger, TAFJSONObjectR jObj, IOPDataImpl iopData) {
		if (jObj == null)
			return;

		Set<String> jKeys = jObj.getKeys();
		for (String name : jKeys) {
			UTF8String value = jObj.getMandatoryStrValue(name);
			iopData.putValue(name, value);
		}
	}

	private static void readJSONObjectIntoStrMap(TAFLogger logger, TAFJSONObjectR jObj,
			Map<String, UTF8String> fields) {
		if (jObj == null)
			return;

		Set<String> jKeys = jObj.getKeys();
		for (String name : jKeys) {
			UTF8String value = jObj.getMandatoryStrValue(name);
			fields.put(name, value);
		}
	}

	private static void readOPValidations(TAFLogger logger, TAFJSONObjectR jObj,
			List<DataDefinitions.Validation> validations, Set<String> reqdCustomValidations) {
		if (jObj == null)
			return;

		Set<String> jKeys = jObj.getKeys();
		for (String key : jKeys) {
			TAFJSONArrayR jValidations = jObj.getMandatoryArray(key);

			for (int idx = 0; idx < jValidations.getSize(); idx++) {
				TAFJSONObjectR jValidation = jValidations.getObject(idx);
				DataDefinitions.VALIDATION_TYPE vt = DataDefinitions.VALIDATION_TYPE.get(key);
				DataDefinitions.Validation validation = DataDefinitions.ddefs.new Validation();
				validation.validationType = vt;
				validations.add(validation);
				if (vt == DataDefinitions.VALIDATION_TYPE.CUSTOM) {
					validation.dataType = VALIDATION_DATA_TYPE.UNKNOWN;
					// Custom validation
					validation.customValidationName = jValidation.getMandatoryStrValue(Constants.JSON.NAME)
							.getUTF8String();
					reqdCustomValidations.add(validation.customValidationName.toLowerCase());
				} else {
					UTF8String type = jValidation.getMandatoryStrValue(Constants.JSON.TYPE);
					validation.dataType = DataDefinitions.VALIDATION_DATA_TYPE.get(type);

					UTF8String output = jValidation.getMandatoryStrValue(Constants.JSON.OUTPUT);
					validation.output = DataDefinitions.ddefs.new Variable(output);

					UTF8String expectedOutput = jValidation.getMandatoryStrValue(Constants.JSON.EXPECTED_OUTPUT);
					if (expectedOutput != null) {
						validation.expectedOutput = DataDefinitions.ddefs.new Variable(expectedOutput);
					}
				}
			}
		}
	}

	public static String file2String(TAFLogger logger, String filePath) throws TAFException {
		String fileContents = "";
		try {
			InputStream is = new FileInputStream(filePath);

			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();

			while (line != null) {
				sb.append(line);
				line = buf.readLine();
			}
			buf.close();
			is.close();
			fileContents = sb.toString();
		} catch (IOException e) {
			if (logger != null) {
				logger.error(e);
			} else {
				e.printStackTrace();
			}

			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "File " + filePath + " seems invalid");
		}

		return fileContents;
	}

	public static void logTestSuites(TAFLogger logger, List<DataDefinitions.TestSuite> testSuites) {
		logger.debug("#testSuites: " + testSuites.size());
		for (DataDefinitions.TestSuite ts : testSuites) {
			logger.debug(ts.name);
			logTestCases(logger, ts.testCases);
		}
	}

	public static void logTestCases(TAFLogger logger, List<DataDefinitions.TestCase> testCases) {
		logger.debug("#testCases: " + testCases.size());
		for (DataDefinitions.TestCase tc : testCases) {
			logger.debug(tc.name);
			logOperations(logger, tc.operations);
		}
	}

	public static void logOperations(TAFLogger logger, List<DataDefinitions.Operation> operations) {
		logger.debug("#operations: " + operations.size());
		for (DataDefinitions.Operation op : operations) {
			logger.debug(op.name);
			logInputs(logger, op.inputs);
			logOPValidations(logger, op.validations);
		}
	}

	public static void logInputs(TAFLogger logger, Map<String, InputField> inputs) {
		logger.debug("#inputs: " + inputs.size());
		StringBuffer sb = new StringBuffer();
		for (Map.Entry<String, InputField> pair : inputs.entrySet()) {
			InputField field = pair.getValue();
			sb.append(field.toString());
			sb.append(" | ");
		}
		logger.debug(sb.toString());
	}

	public static void logOPValidations(TAFLogger logger, List<DataDefinitions.Validation> opValidations) {
		logger.debug("#opValidations: " + opValidations.size());
		for (DataDefinitions.Validation opv : opValidations) {
			StringBuffer sb = new StringBuffer();
			sb.append(opv.validationType.getName());
			sb.append("-");
			if (opv.validationType == VALIDATION_TYPE.CUSTOM) {
				sb.append(opv.customValidationName);
			} else {
				sb.append(opv.dataType.getName());
				sb.append("--");
				sb.append(opv.output.toString());
				if (opv.expectedOutput != null) {
					sb.append(" | ");
					sb.append(opv.expectedOutput.toString());
				}
			}
			logger.debug(sb.toString());
		}
	}

	public static void loadExecutorConfigurations(TAFLogger logger, TAFJSONObjectR jExecConfigs,
			Map<String, IOPDataImpl> executorConfigMap) {
		if (jExecConfigs == null)
			return;

		Set<String> jKeys = jExecConfigs.getKeys();
		for (String name : jKeys) {
			TAFJSONObjectR jConfigs = jExecConfigs.getMandatoryObject(name);
			IOPDataImpl configs = new IOPDataImpl();
			executorConfigMap.put(name, configs);
			readJSONObjectIntoIOPData(logger, jConfigs, configs);
		}
	}

	public static void validateStrSetAgainstSet(String ctx, Set<String> reqdSet, Set<String> supportedSet,
			List<TAFException> exList) {
		Set<String> unsupportedSet = new HashSet<String>();
		for (String str : reqdSet) {
			if (!supportedSet.contains(str)) {
				unsupportedSet.add(str);
			}
		}
		if (!unsupportedSet.isEmpty()) {
			exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS,
					"There are unsupported " + ctx + " : " + unsupportedSet.toString()));
		}
	}

	public static String trimAdvanced(String value) {
		Objects.requireNonNull(value);

		int strLength = value.length();
		int len = value.length();
		int st = 0;
		char[] val = value.toCharArray();

		if (strLength == 0) {
			return "";
		}

		while ((st < len) && (val[st] <= ' ') || (val[st] == '\u00A0')) {
			st++;
			if (st == strLength) {
				break;
			}
		}
		while ((st < len) && (val[len - 1] <= ' ') || (val[len - 1] == '\u00A0')) {
			len--;
			if (len == 0) {
				break;
			}
		}

		return (st > len) ? "" : ((st > 0) || (len < strLength)) ? value.substring(st, len) : value;
	}
}

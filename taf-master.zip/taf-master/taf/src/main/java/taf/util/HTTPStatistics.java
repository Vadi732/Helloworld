package taf.util;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import taf.te.interfaces.TAFLogger;
import taf.te.util.TAFException;

public class HTTPStatistics {
	public class URIStats {
		URIStats() {
			numCalls = 0;
			totalLatency = 0;
			maxLatency = -1; 
			minLatency = -1; 
		}
		int numCalls;
		double totalLatency;
		int maxLatency; 
		int minLatency; 

		public int getNumCalls() {
			return numCalls;
		}
		public double getTotalLatency() {
			return totalLatency;
		}
		public double getAvgLatency() {
			return (numCalls > 0 ? totalLatency/numCalls : 0);
		}
		public int getMaxLatency() {
			return maxLatency;
		}
		public int getMinLatency() {
			return minLatency;
		}
	}
	
	Map<String, URIStats> uriStatsMap;
	String fullPath;
	
	public HTTPStatistics(String fullPath) {
		uriStatsMap = new HashMap<String, URIStats>();
		this.fullPath = fullPath;
	}
	
	public void addRespTime(String uri, int respTime) {
		URIStats stat = null;
		if(uriStatsMap.containsKey(uri)) {
			stat = uriStatsMap.get(uri); 
		} else {
			stat = new URIStats();
			uriStatsMap.put(uri, stat);
		}
		stat.numCalls++;
		stat.totalLatency += respTime;
		if(respTime > stat.maxLatency) {
			stat.maxLatency = respTime;
		}
		if(stat.minLatency < 0) {
			stat.minLatency = respTime; 
		} else if(respTime < stat.minLatency) {
			stat.minLatency = respTime;
		}
	}
	
	public void generateReport(TAFLogger logger) throws IOException, TAFException {
		Excel excel = new Excel();
		List<Excel.XLRow> rows = new ArrayList<Excel.XLRow>();
		Excel.XLRow header = Excel.newXLRow();
		Map<Integer, String> headerCols = header.getCols();
		headerCols.put(0, "URI");
		headerCols.put(1, "TotalNumCalls");
		headerCols.put(2, "TotalResponseTimeMS");
		headerCols.put(3, "MaxResponseTimeMS");
		headerCols.put(4, "MinResponseTimeMS");
		headerCols.put(5, "AvgResponseTimeMS");
		rows.add(header);
		
		for(Map.Entry<String, URIStats> pair : uriStatsMap.entrySet()) {
			String uri = pair.getKey();
			URIStats uriStats = pair.getValue();
			Excel.XLRow row = Excel.newXLRow();
			rows.add(row);
			Map<Integer, String> cols = row.getCols();
			cols.put(0, uri);
			cols.put(1, Integer.toString(uriStats.getNumCalls()));
			cols.put(2, Double.toString(uriStats.getTotalLatency()));
			cols.put(3, Integer.toString(uriStats.getMaxLatency()));
			cols.put(4, Integer.toString(uriStats.getMinLatency()));
			cols.put(5, Double.toString(uriStats.getAvgLatency()));
		}
		
		excel.writeToXLFile(logger, rows, fullPath);
	}
}

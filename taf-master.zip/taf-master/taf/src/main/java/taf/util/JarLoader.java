package taf.util;

import java.io.File;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;

public class JarLoader {

	public static int collectJarsGetURLs(String context, TAFLogger logger, List<String> jarPaths,
			Map<String, List<File>> path2FilesList) {
		context += ":collectJarsGetURLs:";
		int totalFiles = 0;

		for (String jarPath : jarPaths) {
			File loc = new File(jarPath);
			File[] flist = loc.listFiles((File file) -> file.getPath().toLowerCase().endsWith(".jar"));
			if (flist == null)
				continue;

			List<File> fileList = new ArrayList<File>();
			path2FilesList.put(jarPath, fileList);
			for (File file : flist) {
				logger.debug(context + " adding file " + file.getAbsolutePath());
				totalFiles++;
				fileList.add(file);
			}
		}

		return totalFiles;
	}

	public static void loadClasses(String context, TAFLogger logger, List<File> fileList, List<ClassLoader> clsLoaders,
			Set<String> interfaceStrs, Set<Object> modules) throws TAFException {
		if (fileList == null || fileList.isEmpty()) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, context + " file list is empty");
		}

		for (File jfile : fileList) {
			//String jarName = jfile.getName();
			//logger.debug(context + ": processing jar: " + jarName);

			Set<String> listOfClasses = new HashSet<String>();
			try {
				JarInputStream jis = new JarInputStream(new FileInputStream(jfile));
				JarEntry jarEntry;

				while (true) {
					jarEntry = jis.getNextJarEntry();
					if (jarEntry == null) {
						break;
					}

					if ((jarEntry.getName().endsWith(".class"))) {
						String className = jarEntry.getName().replaceAll("/", "\\.");
						String myClass = className.substring(0, className.lastIndexOf('.'));
						listOfClasses.add(myClass);
						//logger.debug(context + ": jarName: " + jarName + " ClsName: " + className);
						Class<?> cls = loadClass(logger, myClass, clsLoaders);

						if (cls != null && interfaceStrs != null && !interfaceStrs.isEmpty() && modules != null) {
							Class<?>[] interfaces = cls.getInterfaces();
							for (int idx = 0; idx < interfaces.length; idx++) {
								//logger.debug(context + ": jarName: " + jarName + " ClsName: " + className
								//		+ " Checking IFName: " + interfaces[idx].getTypeName());

								if (interfaceStrs.contains(interfaces[idx].getTypeName())) {
									Object interfaceObj = cls.getDeclaredConstructor().newInstance();
									modules.add(interfaceObj);
									//logger.debug(context + ": jarName: " + jarName + " ClsName: " + className
									//		+ " Checking IFName: " + interfaces[idx].getTypeName() + " FOUND OBJECT!");
								}
							}
						}
					}
				}
				jis.close();
			} catch (IOException e) {
				logger.error(e);
			} catch (NoClassDefFoundError ex) {
				logger.error(new TAFException(ex));
			} catch (InstantiationException e) {
				logger.error(e);
			} catch (IllegalAccessException e) {
				logger.error(e);
			} catch (IllegalArgumentException e) {
				logger.error(e);
			} catch (InvocationTargetException e) {
				logger.error(e);
			} catch (NoSuchMethodException e) {
				logger.error(e);
			} catch (SecurityException e) {
				logger.error(e);
			}
		}
	}

	public static void getAdditionalInterface(String context, TAFLogger logger,
			String interfaceStr, Set<Object> modules, Set<Object> interfaceObjs) {
		for(Object mod : modules) {
			//String className = mod.getClass().getTypeName();
			Class<?>[] interfaces = mod.getClass().getInterfaces();
			for (int idx = 0; idx < interfaces.length; idx++) {
				//logger.debug(context + ": ClsName: " + className
				//		+ " Checking IFName: " + interfaces[idx].getTypeName());

				if (interfaceStr.equals(interfaces[idx].getTypeName())) {
					interfaceObjs.add(mod);
					//logger.debug(context + ": ClsName: " + className
					//		+ " Checking IFName: " + interfaces[idx].getTypeName() + " FOUND OBJECT!");
				}
			}
		}
	}
	public static Class<?> getClass(TAFLogger logger, String myClass, boolean bInit, URLClassLoader childClsLoader)
			throws TAFException {
		Class<?> cls = null;
		ClassLoader clsLoader = childClsLoader;
		do {
			try {
				cls = Class.forName(myClass, true, clsLoader);
			} catch (ClassNotFoundException e) {
			} catch (NoClassDefFoundError e) {
			}
		} while ((clsLoader = clsLoader.getParent()) != null);

		if (cls == null)
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, myClass + " not loaded!");
		return cls;
	}

	public static Class<?> loadClass(TAFLogger logger, String myClass, List<ClassLoader> classLoaders)
			throws TAFException {
		Class<?> cls = null;
		TAFException ex = null;
		for (ClassLoader clsLoader : classLoaders) {
			try {
				//logger.debug("Trying to load " + myClass + " using " + clsLoader);
				//cls = clsLoader.loadClass(myClass);
				cls = Class.forName(myClass, true, clsLoader);
				//logger.debug("Class " + cls.getName() + " loaded successfully using " + clsLoader);
				break;
			} catch (ClassNotFoundException e) {
				ex = new TAFException(e);
			} catch (NoClassDefFoundError e) {
				ex = new TAFException(e);
			}
		}

		if (cls == null) {
			throw ex;
		}
		return cls;
	}

	public static List<ClassLoader> getAllUpwardClasses(TAFLogger logger, ClassLoader childClsLoader) {
		List<ClassLoader> revClassLoaders = new ArrayList<ClassLoader>();
		while (childClsLoader != null) {
			revClassLoaders.add(childClsLoader);
			//logger.debug("childClsLoader: " + childClsLoader.getClass().getName() + " : " + childClsLoader);
			childClsLoader = childClsLoader.getParent();
		}

		int numClasses = revClassLoaders.size();
		List<ClassLoader> classLoaders = new ArrayList<ClassLoader>();
		for (int idx = numClasses - 1; idx >= 0; idx--) {
			classLoaders.add(revClassLoaders.get(idx));
		}

		return classLoaders;
	}
}

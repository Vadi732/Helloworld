package taf.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import taf.te.interfaces.HttpCommunicator;
import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;

public class HttpCommunicatorImpl implements HttpCommunicator {
	public static final List<Integer> HTTP_SUCCESS_CODES = new ArrayList<Integer>(Arrays.asList(200));

	private String host = null;
	private String method = null;
	private boolean bSSL = false;
	private Map<String, String> headers = new HashMap<String, String>();
	private Map<String, String> qparams = new HashMap<String, String>();
	private int responseCode = -1;
	private String postData = "";

	private StringBuilder directory = new StringBuilder();
	HTTPStatistics httpStatistics;
	
	public HttpCommunicatorImpl(HTTPStatistics httpStatistics) {
		this.httpStatistics = httpStatistics;
	}

	public void resetPath() {
		directory = new StringBuilder();
	}

	public void addPath(String path) {
		directory.append("/");
		directory.append(path);
	}
	
	public void addContent(String content) {
		directory.append(content);
	}

	public void addHeader(String pn, String pv) {
		if (headers.containsKey(pn)) {
			headers.remove(pv);
		}
		headers.put(pn, pv);
	}

	public void addQuerryParameter(String parameter, String value) {
		if(qparams.containsKey(parameter)) {
			qparams.remove(parameter);
		}
		qparams.put(parameter, value);
	}

	public void setPostData(String postData) {
		this.postData = postData;
	}
	
	public int getResponseCode() {
		return responseCode;
	}

	public UTF8String send(TAFLogger logger, int retryCount, int retrySleepMS) throws TAFException {
		UTF8String response = null;
		boolean bRetry = false;

		do {
			if (bRetry) {
				logger.info("Attempting send - receive again");
			}
			bRetry = false;
			try {
				response = sendRcv(logger);
			} catch (URISyntaxException ex) {
				logger.error(ex);
			} catch (IOException ex) {
				bRetry = true;
				logger.error(ex);
				try {
					Thread.sleep(retrySleepMS);
				} catch (InterruptedException e) {
				}
			}
		} while (bRetry && (retryCount-- > 0));
		return response;
	}

	private String getQParamsString() {
		StringBuilder qparamsStr = new StringBuilder();
		for(Map.Entry<String, String> qPair : qparams.entrySet()) {
			if (qparamsStr.toString().length() > 0) {
				qparamsStr.append("&");
			}
			qparamsStr.append(qPair.getKey());
			qparamsStr.append("=");
			qparamsStr.append(qPair.getValue());
		}
		
		return qparamsStr.toString();
	}
	
	private UTF8String sendRcv(TAFLogger logger) throws TAFException, URISyntaxException, IOException {
		logger.debug(postData);
		UTF8String response = null;
		String connType = "http";
		if (bSSL) {
			connType = "https";
		}

		long startTime = System.currentTimeMillis();
		String uri = directory.toString();
		URL url = new URI(connType, host, uri, getQParamsString(), null).toURL();
		logger.debug(url.toString());
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setRequestMethod(method);

		for (Map.Entry<String, String> hdrPair : headers.entrySet()) {
			con.setRequestProperty(hdrPair.getKey(), hdrPair.getValue());
		}

		if(method.equalsIgnoreCase(METHOD_POST)) {
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
			osw.write(postData);
			osw.flush();
			osw.close();
			os.close();
		}
		
		responseCode = con.getResponseCode();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), Charset.forName("UTF-8")));
		String inputLine;

		StringBuilder sb = new StringBuilder();
		String responseData = "";

		while ((inputLine = in.readLine()) != null) {
			sb.append(inputLine);
		}
		in.close();
		responseData = sb.toString();

		long endTime = System.currentTimeMillis();
		int respTime = (int)(endTime - startTime); 
		httpStatistics.addRespTime(uri, respTime);
		
		if (HTTP_SUCCESS_CODES.contains(responseCode)) {
			response = new UTF8String(responseData);
		} else {
			logger.error("Response Data " + responseData);

			TAFException tafException = new TAFException(ProcessingCode.HTTP_ERROR, "Http request returned: " + responseCode + " for url: " + url.toString());
			throw tafException;
		}
		return response;
	}

	public void setHostParams(String host, boolean bSSL) {
		this.host = host;
		this.bSSL = bSSL;
	}
	
	public void setMethod(String method) {
		this.method = method;
	}
}

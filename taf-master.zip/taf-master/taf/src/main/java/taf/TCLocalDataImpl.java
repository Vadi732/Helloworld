package taf;

import java.util.HashMap;
import java.util.Map;

import taf.te.interfaces.TCLocalData;

public class TCLocalDataImpl implements TCLocalData {

	Map<String, Object> tclCache;
	
	public TCLocalDataImpl() {
		tclCache = new HashMap<String, Object>();
	}
	public Object getValue(String name) {
		return tclCache.get(name);
	}

	public void putValue(String name, Object value) {
		tclCache.put(name, value);
	}
}

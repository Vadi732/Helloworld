package taf;

import java.util.HashMap;
import java.util.Map;

import taf.te.interfaces.InputData;
import taf.te.interfaces.OutputData;
import taf.te.util.UTF8String;

public class IOPDataImpl implements InputData, OutputData {

	Map<String, UTF8String> data;
	
	public IOPDataImpl() {
		data = new HashMap<String, UTF8String>();
	}
	public void putValue(String name, UTF8String value) {
		data.put(name, value);
	}

	public UTF8String getValue(String name) {
		return data.get(name);
	}
}

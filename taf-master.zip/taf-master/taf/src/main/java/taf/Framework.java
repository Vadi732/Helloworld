package taf;

import java.io.File;


import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import taf.DataDefinitions.InputField;
import taf.DataDefinitions.Operation;
import taf.DataDefinitions.Variable;
import taf.te.interfaces.TAFExecInterface;
import taf.te.interfaces.TAFJSONArrayR;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;
import taf.util.BasicValidator;
import taf.util.Constants;
import taf.util.FileCfgHandler;
import taf.util.HTTPStatistics;
import taf.util.JarLoader;
import taf.util.TAFJSONFactoryImpl;
import taf.util.TAFLoggerFactory;
import taf.util.Util;

public class Framework {
	private static Framework oneAndOnly = null;
	
	String rootPath = null;
	private TAFLogger logger = null;
	private FileCfgHandler fch = null;
	private TAFJSONObjectR jCfgRoot = null;
	private TAFServiceFactoryImpl tafSvcImpl = null;
	private Map<String, Integer> opName2IdMap;
	private Map<String, TAFExecInterface> op2ExecObj = null;
	private Map<String, TAFExecInterface> validation2ExecObj = null;
	private Set<String> executorClassNames;
	private Set<String> testSuites2Execute;
	private List<DataDefinitions.TestSuite> testSuites;
	private Map<String, DataDefinitions.DataFile> dataFilesMap;
	private Map<DataDefinitions.TestSuite, Map<String, UTF8String>> tsGlobalCache;
	private Map<String, IOPDataImpl> executorConfigMap;
	
	private int numIterations;
	private int iterationStart;
	private int numThreads;
	
	HTTPStatistics httpStatistics;
	
	private Map<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> tsInitRunResults;
	private Map<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> tsRunResults;
	
	Set<String> reqdOps;
	Set<String> reqdCustomValidations;
	
	public static void main(String[] args) {
		oneAndOnly = new Framework();
		try {
			oneAndOnly.init();
			//ProcessTWTReviews.processReviews(oneAndOnly.logger);
			oneAndOnly.executeTestSuites();
			oneAndOnly.validateTestSuiteResults();
			FWUtils.createXLTestReports(oneAndOnly.logger, oneAndOnly.rootPath, oneAndOnly.tsRunResults);
			oneAndOnly.logHTTPStatistics();
		} catch(TAFException | IOException | ClassCastException | IllegalArgumentException ex) {
			if(oneAndOnly.logger == null) {
				ex.printStackTrace();
			} else {
				oneAndOnly.logger.error(ex);
			}
		}
	}

	public void logHTTPStatistics() throws IOException, TAFException {
		httpStatistics.generateReport(logger);
	}
	
	private void init() throws TAFException, IOException, ClassCastException {
		rootPath = System.getenv(Constants.ROOT_PATH);
		
		String statsReportPath = rootPath + File.separator + Constants.LOGS_PATH + File.separator + "uri_stats.xlsx";
		httpStatistics = new HTTPStatistics(statsReportPath);

		FWUtils.init(rootPath + File.separator + Constants.FILES_PATH);
		
		jCfgRoot = loadJSONConfiFile();
		
		TAFJSONObjectR jParams = jCfgRoot.getMandatoryObject(Constants.JSON.PARAMETERS);
		fch = new FileCfgHandler();
		fch.loadPropertiesFile(jParams);
		
		TAFLoggerFactory.init(rootPath, fch);
		logger = TAFLoggerFactory.create("Framework");
		
		executorClassNames = new HashSet<String>();
		Util.loadTestExecutorClassNames(logger, jCfgRoot, executorClassNames);

		TAFJSONObjectR jExecConfigs = jCfgRoot.getMandatoryObject(Constants.JSON.TEST_EXECUTOR_CONFIGS);
		executorConfigMap = new HashMap<String, IOPDataImpl>();
		Util.loadExecutorConfigurations(logger, jExecConfigs, executorConfigMap);
		
		loadRunConfigurations();
		
		tafSvcImpl = new TAFServiceFactoryImpl(httpStatistics);
		op2ExecObj = new HashMap<String, TAFExecInterface>();
		validation2ExecObj = new HashMap<String, TAFExecInterface>();
		opName2IdMap = new HashMap<String, Integer>();
		
		List<String> jarPaths = new ArrayList<String>();
		String path = rootPath + File.separator + Constants.TE_PATH;
		jarPaths.add(path);
		Map<String, List<File>> path2FilesList = new HashMap<String, List<File>>();
		int totalFiles = JarLoader.collectJarsGetURLs("loadExecutors", logger, jarPaths, path2FilesList);
		URL[] urlArray = new URL[totalFiles];
		int idx = 0;
		for (Map.Entry<String, List<File>> pair : path2FilesList.entrySet()) {
			for (File file : pair.getValue()) {
				try {
					urlArray[idx] = file.toURI().toURL();
					idx++;
				} catch (MalformedURLException e) {
					logger.error(e);
				}
			}
		}

		ClassLoader clsLoader = Thread.currentThread().getContextClassLoader();
		URLClassLoader childClsLoader = new URLClassLoader(urlArray, clsLoader);
		List<ClassLoader> clsLoaders = new ArrayList<ClassLoader>();
		clsLoaders.add(childClsLoader);
		
		Set<String> interfaceStrs = new HashSet<String>();
		Set<Object> modules = new HashSet<Object>();
		interfaceStrs.add("taf.te.interfaces.TAFExecInterface");
		JarLoader.loadClasses("loadExecutors", logger, path2FilesList.get(path), clsLoaders, interfaceStrs, modules);

		for(Object mod : modules) {
			TAFExecInterface tafi = (TAFExecInterface) mod;
			IOPDataImpl configParams = executorConfigMap.get(tafi.getClass().getSimpleName());
			tafi.init(logger, tafSvcImpl, configParams);
			Map<String, Integer> localMap = new HashMap<String, Integer>();
			tafi.getSupportedOperations(logger, tafSvcImpl, localMap);

			for (Map.Entry<String, Integer> pair : localMap.entrySet()) {
				String opl = pair.getKey().toLowerCase();
				if(opName2IdMap.containsKey(opl)) {
					throw new TAFException(ProcessingCode.INVALID_CONTENTS, "OpName: " + pair.getKey() + " is duplicate");
				} else {
					opName2IdMap.put(opl, pair.getValue());
				}
				op2ExecObj.put(opl, tafi);
			}

			Set<String> validations = new HashSet<String>();
			tafi.getSupportedValidations(logger, tafSvcImpl, validations);
			for (String vd : validations) {
				String vdl = vd.toLowerCase();
				validation2ExecObj.put(vdl, tafi);
			}
		}
		TAFJSONArrayR jTS2Execute = jCfgRoot.getMandatoryArray(Constants.JSON.TEST_SUITES_TO_EXECUTE);
		testSuites2Execute = new HashSet<String>();
		Util.readJSONArrayIntoStringCollection(logger, jTS2Execute, testSuites2Execute);
		
		if(testSuites2Execute.isEmpty()) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "No test suites are configured for execution in the configuration file!");
		}
		
		testSuites = new ArrayList<DataDefinitions.TestSuite>();
		reqdOps = new HashSet<String>();
		reqdCustomValidations = new HashSet<String>();
		TAFJSONFactoryImpl jFactory = new TAFJSONFactoryImpl(); 
		Util.loadTestSuites(logger, jFactory, rootPath, testSuites2Execute, testSuites, reqdOps, reqdCustomValidations, opName2IdMap);
		Util.logTestSuites(logger, testSuites);
	
		List<TAFException> exList = new ArrayList<TAFException>(); 
		validateTestSuites(exList);
		if(!exList.isEmpty()) {
			logExceptions(logger, exList);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Errors in Testsuites");
		}
		
		dataFilesMap = new HashMap<String, DataDefinitions.DataFile>();
		Util.loadDataFiles(logger, rootPath, dataFilesMap);
		validateDataFiles(exList);
		if(!exList.isEmpty()) {
			logExceptions(logger, exList);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Errors in Datafiles");
		}
		validateTSAgainstDF(exList);
		if(!exList.isEmpty()) {
			logExceptions(logger, exList);
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Errors in Testsuite datafile names");
		}
	}

	private void executeTestSuites() throws TAFException {
		executeTestSuiteInits();
		boolean bInitRunRes = FWUtils.validateTSResults(tsInitRunResults);
		if(!bInitRunRes) {
			logger.error("One or more test suite init validation failed. Can't proceed");
			return;
		}
		
		ExecutorService executor = Executors.newFixedThreadPool(numThreads);
		
		tsRunResults = new HashMap<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>>();
		
		for(DataDefinitions.TestSuite ts : testSuites) {
			DataDefinitions.DataFile df = dataFilesMap.get(ts.dfName);
			
			List<DataDefinitions.TestSuiteRunResults> runResults = new ArrayList<DataDefinitions.TestSuiteRunResults>();
			tsRunResults.put(ts, runResults);
			for(int runId = iterationStart; runId < numIterations + iterationStart; runId++) {
				for(Map<String, UTF8String> data : df.data) {
					Map<String, UTF8String> cache = new HashMap<String, UTF8String>();
					if(tsGlobalCache.containsKey(ts)) {
						Map<String, UTF8String> gcache = tsGlobalCache.get(ts);
						cache.putAll(gcache);
					}
					
					DataDefinitions.TestSuiteRunResults tsrr = DataDefinitions.ddefs.new TestSuiteRunResults(runId);
					runResults.add(tsrr);
					
					MTExecutorData mtd = new MTExecutorData(runId, ts, df.constants, data, cache, tsrr);
					MTExecutor mte = new MTExecutor(this, mtd);
					executor.submit(mte);
				}
			}
		}
	}

	private void validateTestSuiteResults() {
		FWUtils.validateTSResults(tsRunResults);
	}

	private void executeTestSuiteInits() throws TAFException {
		tsGlobalCache = new HashMap<DataDefinitions.TestSuite, Map<String, UTF8String>>();
		tsInitRunResults = new HashMap<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> ();
		Map<String, UTF8String> cache = new HashMap<String, UTF8String>();
		IOPDataImpl outputs = new IOPDataImpl();
		
		for(DataDefinitions.TestSuite ts : testSuites) {
			DataDefinitions.DataFile df = dataFilesMap.get(ts.dfName);
			List<DataDefinitions.TestSuiteRunResults> tsrrList = new ArrayList<DataDefinitions.TestSuiteRunResults>();
			DataDefinitions.TestSuiteRunResults tsrr = DataDefinitions.ddefs.new TestSuiteRunResults(1);
			tsrrList.add(tsrr);
			
			DataDefinitions.TestCaseRunResults tcrr = DataDefinitions.ddefs.new TestCaseRunResults("init");

			TCLocalDataImpl tclData = new TCLocalDataImpl();
			executeOperations(logger, 1, ts.initOps, cache, df.initData, outputs, tclData, df.constants, tcrr.getResults());
			tsGlobalCache.put(ts, cache);
			tsInitRunResults.put(ts, tsrrList);
		}
	}
	
	public void executeOperations(TAFLogger tsLogger, int runId, List<Operation> operations, Map<String, UTF8String> cache, Map<String, UTF8String> data, IOPDataImpl outputs, TCLocalDataImpl tclData, Map<String, UTF8String> constants, List<DataDefinitions.OperationRunResults> opResultsList) throws TAFException {
		for(DataDefinitions.Operation op : operations) {
			DataDefinitions.OperationRunResults opResult = DataDefinitions.ddefs.new OperationRunResults(op.name, tsLogger);
			opResultsList.add(opResult);
			executeOperation(tsLogger, runId, op, cache, data, outputs, tclData, constants, opResult.getResults());
		}
	}
	
	private void executeOperation(TAFLogger tsLogger, int runId, DataDefinitions.Operation op, Map<String, UTF8String> cache, Map<String, UTF8String> data, IOPDataImpl outputs, TCLocalDataImpl tclData, Map<String, UTF8String> constants, List<BasicValidator> results) throws TAFException {
		IOPDataImpl inputs = new IOPDataImpl();
		TAFExecInterface tafi = op2ExecObj.get(op.name);
		if(tafi == null) {
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "No takers for Operation: " + op.name);
		}
		DataDefinitions.SystemProc sysProc = DataDefinitions.ddefs.new SystemProc(runId);
		
		for(Map.Entry<String, InputField> pair : op.inputs.entrySet()) {
			InputField field = pair.getValue();
			UTF8String value = field.getParameterValue(sysProc, cache, data, outputs, constants);
			inputs.putValue(field.getName(), value);
		}
		try {
			tafi.execute(tsLogger, tafSvcImpl, op.id, inputs, outputs, tclData);
			FWUtils.resolveReferences(tsLogger, op.validations, sysProc, cache, data, outputs, op.inputs, constants, results);
			FWUtils.processCustomValidations(tsLogger, tafSvcImpl, validation2ExecObj, op, cache, data, outputs, tclData, results);
			//perform cache request if present
			if(op.cache != null) {
				for(Map.Entry<String, Variable> paramEntry : op.cache.entrySet()) {
					UTF8String value = FWUtils.getParameterValue(paramEntry.getValue(), sysProc, cache, data, outputs, op.inputs, constants);
					cache.put(paramEntry.getKey(), value);
				}
			}
		} catch (TAFException e) {
			tsLogger.error(e);
		}
	}
	
	private TAFJSONObjectR loadJSONConfiFile() throws IOException, TAFException {
		TAFJSONObjectR jCfgRoot = null;
		System.out.println("Root:" + rootPath);
		
		String cfgPropFile = rootPath + File.separator + Constants.CFG_PATH + File.separator + Constants.CFG_FILE_NAME;
		System.out.println("Reading configurations from: " + cfgPropFile);
		String jsonContents = Util.file2String(null, cfgPropFile);		
		jCfgRoot = parseConfigFile(jsonContents);
		return jCfgRoot;
	}

	private TAFJSONObjectR parseConfigFile(String jsonContents) throws TAFException {
		TAFJSONFactoryImpl jFactory = new TAFJSONFactoryImpl(); 
		TAFJSONObjectR jRoot = jFactory.parseJSON(new UTF8String(jsonContents));
		if(jRoot == null)
			throw new TAFException(ProcessingCode.INVALID_CONTENTS, "Looks like JSON configration file is not ok");
		return jRoot;
	}
	
	private void loadRunConfigurations() {
		TAFJSONObjectR jRunConfigs = jCfgRoot.getMandatoryObject("run_configurations");
		if(jRunConfigs != null) {
			UTF8String sVal = jRunConfigs.getOptionalStrValue("num_iterations", "1");
			numIterations = Integer.parseInt(sVal.getUTF8String());
			sVal = jRunConfigs.getOptionalStrValue("iteration_start", "1");
			iterationStart = Integer.parseInt(sVal.getUTF8String());
			sVal = jRunConfigs.getOptionalStrValue("num_threads", "1");
			numThreads = Integer.parseInt(sVal.getUTF8String());
		}
	}
	private void validateTestSuites(List<TAFException> exList) {
		for(DataDefinitions.TestSuite ts : testSuites) {
			ts.validate("VALIDATION", exList);
		}
		//validate if all required operations and validations are supported by loaded Test executors
		Util.validateStrSetAgainstSet("operations", reqdOps, op2ExecObj.keySet(), exList);
		Util.validateStrSetAgainstSet("customValidations", reqdCustomValidations, validation2ExecObj.keySet(), exList);
	}

	private void validateDataFiles(List<TAFException> exList) {
		for(Map.Entry<String, DataDefinitions.DataFile> pair : dataFilesMap.entrySet()) {
			pair.getValue().validate("VALIDATION", exList);
		}
	}

	private void validateTSAgainstDF(List<TAFException> exList) {
		for(DataDefinitions.TestSuite ts : testSuites) {
			if(!dataFilesMap.containsKey(ts.dfName)) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, "TS: " + ts.name + " has missing datafile: " + ts.dfName));
			}
		}
	}
	
	private void logExceptions(TAFLogger logger, List<TAFException> exList) {
		for(TAFException ex : exList) {
			logger.error(ex);
		}
	}
}

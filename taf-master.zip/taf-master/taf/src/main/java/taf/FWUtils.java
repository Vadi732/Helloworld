package taf;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import taf.DataDefinitions.InputField;
import taf.DataDefinitions.Operation;
import taf.DataDefinitions.SystemProc;
import taf.DataDefinitions.VALIDATION_TYPE;
import taf.DataDefinitions.Validation;
import taf.te.interfaces.TAFExecInterface;
import taf.te.interfaces.TAFLogger;
import taf.te.interfaces.TAFServicesFactory;
import taf.te.interfaces.TCLocalData;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;
import taf.util.BasicValidator;
import taf.util.Constants;
import taf.util.Excel;
import taf.util.Util;

public class FWUtils {
	public static String filePath;
	private static final int MAX_SIZE = 10240;
	
	public static void init(String filePath) {
		FWUtils.filePath = filePath;
	}
	
	protected static UTF8String getParameterValue(DataDefinitions.Variable param, SystemProc system, Map<String, UTF8String> cache,
			Map<String, UTF8String> data, IOPDataImpl outputs, Map<String, InputField> inputs, Map<String, UTF8String> constants) {
		UTF8String value = null;
		if (param.getValue() != null) {
			switch (param.getDataSvcType()) {
			case INLINE:
				value = param.getValue();
				break;
			case CACHE:
				value = cache.get(param.getValue().getUTF8String());
				break;
			case DATA:
				value = data.get(param.getValue().getUTF8String());
				break;
			case OUTPUT:
				value = outputs.getValue(param.getValue().getUTF8String());
				break;
			case FILE:
				try {
					String fPath = filePath + File.separator + param.getValue().getUTF8String();
					value = new UTF8String(Util.file2String(null, fPath));
				} catch (TAFException e) {
					e.printStackTrace();
				}
				break;
			case SYSTEM:
				value = system.getValue(param.getValue().getUTF8String());
				break;
			case INPUT:
				if(inputs != null) {
					value = inputs.get(param.getValue().getUTF8String()).getParameterValue(system, cache, data, outputs, constants);
				}
				break;
			case CONSTANTS:
				value = constants.get(param.getValue().getUTF8String());
				break;
			default:
				break;
			}
		}
		return value;
	}

	protected static void resolveReferences(TAFLogger logger, List<Validation> validations, SystemProc system, Map<String, UTF8String> cache,
			Map<String, UTF8String> data, IOPDataImpl outputs, Map<String, InputField> inputs, Map<String, UTF8String> constants, List<BasicValidator> results) {
		for (Validation opv : validations) {
			if (opv.validationType == VALIDATION_TYPE.CUSTOM) {
				// Do not process custom validations here.
				// Moreover there's no data to be given so no question of resolving any
				// references
				continue;
			}
			BasicValidator bv = new BasicValidator(opv.validationType, opv.dataType);
			if (opv.output != null) {
				UTF8String value = getParameterValue(opv.output, system, cache, data, outputs, inputs, constants);
				String name = opv.output.getDataSvcType().getName() + "." + opv.output.getValue().getUTF8String();
				bv.setVarData(name, value);
			}
			if (opv.expectedOutput != null) {
				UTF8String value = getParameterValue(opv.expectedOutput, system, cache, data, outputs, inputs, constants);
				String name = opv.expectedOutput.getDataSvcType().getName() + "." + opv.expectedOutput.getValue().getUTF8String();
				bv.setMatchData(name, value);
			}
			results.add(bv);
		}
	}

	protected static void processCustomValidations(TAFLogger logger, TAFServicesFactory tafSvc,
			Map<String, TAFExecInterface> validation2ExecObj, Operation op, Map<String, UTF8String> cache,
			Map<String, UTF8String> data, IOPDataImpl outputs, TCLocalData tclData, List<BasicValidator> results) {
		for (Validation opv : op.validations) {
			if (opv.validationType == VALIDATION_TYPE.CUSTOM) {
				BasicValidator bv = new BasicValidator(opv.validationType, opv.dataType);
				results.add(bv);
				TAFExecInterface tafi = validation2ExecObj.get(opv.customValidationName);
				bv.validateCustom(logger, tafSvc, tafi, op.name, opv.customValidationName, cache, outputs, tclData);
			}
		}
	}

	protected static boolean validateTSResults(Map<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> ts2Results) {
		boolean bRes = true;
		for (Map.Entry<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> tsPair : ts2Results
				.entrySet()) {
			List<DataDefinitions.TestSuiteRunResults> tsrrList = tsPair.getValue();
			for (DataDefinitions.TestSuiteRunResults tsrr : tsrrList) {
				for (DataDefinitions.TestCaseRunResults tcrr : tsrr.getResults()) {
					for (DataDefinitions.OperationRunResults oprr : tcrr.getResults()) {
						TAFLogger logger = oprr.getTSLogger();
						for (BasicValidator bv : oprr.getResults()) {
							bv.validate();
							
							logger.info(bv.toString() + " " + (bv.isSuccess() ? "SUCCESS" : "FAILED"));
							bRes &= bv.isSuccess();
						}
					}
				}
			}
		}
		return bRes;
	}

	protected static void createXLTestReports(TAFLogger logger, String rootPath,
			Map<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> ts2Results)
			throws IOException, TAFException {

		for (Map.Entry<DataDefinitions.TestSuite, List<DataDefinitions.TestSuiteRunResults>> tsPair : ts2Results
				.entrySet()) {
			DataDefinitions.TestSuite ts = tsPair.getKey();
			List<Excel.XLRow> rows = new ArrayList<Excel.XLRow>();
			rows.add(Constants.headerRow);

			List<DataDefinitions.TestSuiteRunResults> tsrrList = tsPair.getValue();
			for (DataDefinitions.TestSuiteRunResults tsrr : tsrrList) {
				for (DataDefinitions.TestCaseRunResults tcrr : tsrr.getResults()) {
					for (DataDefinitions.OperationRunResults oprr : tcrr.getResults()) {
						Excel.XLRow row = Excel.newXLRow();
						row.getCols().put(Constants.XLPositions.RUN_ID, Integer.toString(tsrr.getRunId()));
						row.getCols().put(Constants.XLPositions.TC_NAME, tcrr.getName());
						row.getCols().put(Constants.XLPositions.OP_NAME, oprr.getName());

						int validationsStart = Constants.XLPositions.VALIDATIONS_START;
						boolean bOpResult = true;

						for (BasicValidator bv : oprr.getResults()) {
							String message = bv.getMessage();
							String tmessage = (message == null ? "" : message);
							if(tmessage.length() > MAX_SIZE) {
								tmessage = tmessage.substring(0, MAX_SIZE);
							}
							
							row.getCols().put(validationsStart++, tmessage);
							bOpResult &= bv.isSuccess();
						}
						row.getCols().put(Constants.XLPositions.TEST_RESULT, (bOpResult ? "SUCCESS" : "FAILED"));
						rows.add(row);
					}
				}
			}
			Excel xl = new Excel();
			Calendar rightNow = Calendar.getInstance();
			String month = rightNow.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.ENGLISH);
			String ds = rightNow.get(Calendar.DAY_OF_MONTH) + "_" + month + "_"
					+ rightNow.get(Calendar.YEAR);
			String reportFP = rootPath + File.separator + "reports" + File.separator + ts.name + "_" + ds + ".xlsx";
			xl.writeToXLFile(logger, rows, reportFP);
		}
	}
}

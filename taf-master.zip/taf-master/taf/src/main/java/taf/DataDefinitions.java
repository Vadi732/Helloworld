package taf;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.util.Random;

import taf.te.interfaces.TAFJSONArrayR;
import taf.te.interfaces.TAFJSONObjectR;
import taf.te.interfaces.TAFLogger;
import taf.te.util.ProcessingCode;
import taf.te.util.TAFException;
import taf.te.util.UTF8String;
import taf.util.BasicValidator;

public class DataDefinitions {
	public static DataDefinitions ddefs = new DataDefinitions();

	public enum VALIDATION_TYPE {
		EQUAL_CS(0, "equal_cs"), EQUAL_CIS(1, "equal_cis"), NOT_EQUAL(2, "!equal"), EMPTY(3, "empty"),
		NOT_EMPTY(4, "!empty"), CONTAINS(5, "contains"),

		CUSTOM(1000, "custom"), UNKNOWN(-1, "unknown");

		private int value;
		private String name;
		private static final VALIDATION_TYPE[] vals = VALIDATION_TYPE.values();

		private VALIDATION_TYPE(int value, String name) {
			this.value = value;
			this.name = name;
		}

		public boolean isUnary() {
			return (this == EMPTY || this == NOT_EMPTY);
		}

		public int getValue() {
			return value;
		}

		public String getName() {
			return name;
		}

		public static VALIDATION_TYPE get(int value) {
			for (VALIDATION_TYPE e : VALIDATION_TYPE.vals) {
				if (e.getValue() == value)
					return e;
			}
			return UNKNOWN;
		}

		public static VALIDATION_TYPE get(String name) {
			for (VALIDATION_TYPE e : VALIDATION_TYPE.vals) {
				if (e.name.equalsIgnoreCase(name))
					return e;
			}
			return UNKNOWN;
		}
	}

	public enum VALIDATION_DATA_TYPE {
		STRING(0, "string"), INT(1, "int"), DOUBLE(2, "double"), STR_SET(3, "string_set"),

		UNKNOWN(-1, "unknown");

		private int value;
		private String name;
		private static final VALIDATION_DATA_TYPE[] vals = VALIDATION_DATA_TYPE.values();

		private VALIDATION_DATA_TYPE(int value, String name) {
			this.value = value;
			this.name = name;
		}

		public int getValue() {
			return value;
		}

		public String getName() {
			return name;
		}

		public static VALIDATION_DATA_TYPE get(int value) {
			for (VALIDATION_DATA_TYPE e : VALIDATION_DATA_TYPE.vals) {
				if (e.getValue() == value)
					return e;
			}
			return UNKNOWN;
		}

		public static VALIDATION_DATA_TYPE get(UTF8String name) {
			for (VALIDATION_DATA_TYPE e : VALIDATION_DATA_TYPE.vals) {
				if (e.name.equalsIgnoreCase(name.getUTF8String()))
					return e;
			}
			return UNKNOWN;
		}
	}

	public enum DA_SERVICE_TYPE {
		INLINE(0, "#inline."), DATA(1, "#data."), OUTPUT(2, "#output."), CACHE(3, "#cache."), FILE(4, "#file."), SYSTEM(4, "#system."), INPUT(5, "#input."), CONSTANTS(6, "#constants."),

		UNKNOWN(-1, "unknown");

		private int value;
		private String name;
		private static final DA_SERVICE_TYPE[] vals = DA_SERVICE_TYPE.values();

		private DA_SERVICE_TYPE(int value, String name) {
			this.value = value;
			this.name = name;
		}

		public int getValue() {
			return value;
		}

		public String getName() {
			return name;
		}

		public static DA_SERVICE_TYPE get(int value) {
			for (DA_SERVICE_TYPE e : DA_SERVICE_TYPE.vals) {
				if (e.getValue() == value)
					return e;
			}
			return UNKNOWN;
		}

		public static DA_SERVICE_TYPE get(String name) {
			for (DA_SERVICE_TYPE e : DA_SERVICE_TYPE.vals) {
				if (e.name.equalsIgnoreCase(name))
					return e;
			}
			return UNKNOWN;
		}
	}

	public enum FIELD_OP_TYPE {
		BASIC_RESOLUTION(0, "basic_resolution"), CONCAT(1, "concat"),

		UNKNOWN(-1, "unknown");

		private int value;
		private String name;
		private static final FIELD_OP_TYPE[] vals = FIELD_OP_TYPE.values();

		private FIELD_OP_TYPE(int value, String name) {
			this.value = value;
			this.name = name;
		}

		public int getValue() {
			return value;
		}

		public String getName() {
			return name;
		}

		public static FIELD_OP_TYPE get(int value) {
			for (FIELD_OP_TYPE e : FIELD_OP_TYPE.vals) {
				if (e.getValue() == value)
					return e;
			}
			return UNKNOWN;
		}

		public static FIELD_OP_TYPE get(String name) {
			for (FIELD_OP_TYPE e : FIELD_OP_TYPE.vals) {
				if (e.name.equalsIgnoreCase(name))
					return e;
			}
			return UNKNOWN;
		}
	}

	public class Variable {
		private DA_SERVICE_TYPE daSvcType;
		private UTF8String value;

		public Variable(UTF8String value) {
			daSvcType = DA_SERVICE_TYPE.INLINE;
			this.value = value;
			processValue();
		}

		public void validate(String context, List<TAFException> exList) {
			if (value == null || value.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS,
						context + ": parameter value is null or empty"));
			}
		}

		public String toString() {
			return ("[" + daSvcType.name() + ":" + value + "]");
		}

		public UTF8String getValue() {
			return value;
		}

		public DA_SERVICE_TYPE getDataSvcType() {
			return daSvcType;
		}

		private void processValue() {
			if (value == null || value.getUTF8String() == null || value.getUTF8String().isEmpty())
				return;
			String sValue = value.getUTF8String();
			if (sValue.startsWith("#")) {
				String rValue = null;
				if (sValue.startsWith(DA_SERVICE_TYPE.DATA.getName())) {
					daSvcType = DA_SERVICE_TYPE.DATA;
					rValue = sValue.substring(DA_SERVICE_TYPE.DATA.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.OUTPUT.getName())) {
					daSvcType = DA_SERVICE_TYPE.OUTPUT;
					rValue = sValue.substring(DA_SERVICE_TYPE.OUTPUT.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.CACHE.getName())) {
					daSvcType = DA_SERVICE_TYPE.CACHE;
					rValue = sValue.substring(DA_SERVICE_TYPE.CACHE.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.FILE.getName())) {
					daSvcType = DA_SERVICE_TYPE.FILE;
					rValue = sValue.substring(DA_SERVICE_TYPE.FILE.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.SYSTEM.getName())) {
					daSvcType = DA_SERVICE_TYPE.SYSTEM;
					rValue = sValue.substring(DA_SERVICE_TYPE.SYSTEM.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.INPUT.getName())) {
					daSvcType = DA_SERVICE_TYPE.INPUT;
					rValue = sValue.substring(DA_SERVICE_TYPE.INPUT.getName().length());
				} else if (sValue.startsWith(DA_SERVICE_TYPE.CONSTANTS.getName())) {
					daSvcType = DA_SERVICE_TYPE.CONSTANTS;
					rValue = sValue.substring(DA_SERVICE_TYPE.CONSTANTS.getName().length());
				}
				if (rValue != null) {
					value = new UTF8String(rValue);
				}
			}
		}
	}

	public class InputField {
		private FIELD_OP_TYPE fOPType = FIELD_OP_TYPE.UNKNOWN;
		private List<Variable> fields;
		private String name;

		public InputField(FIELD_OP_TYPE fOPType, String name, TAFJSONObjectR jObj) {
			fields = new ArrayList<Variable>();
			this.fOPType = fOPType;
			if (fOPType == FIELD_OP_TYPE.CONCAT) {
				fields = new ArrayList<Variable>();
				this.name = jObj.getMandatoryStrValue("name").getUTF8String();
				TAFJSONArrayR jValues = jObj.getMandatoryArray("values");
				for (int idx = 0; idx < jValues.getSize(); idx++) {
					fields.add(new Variable(jValues.getStrValue(idx)));
				}
			} else if(fOPType == FIELD_OP_TYPE.BASIC_RESOLUTION) {
				this.name = name;
				UTF8String value = jObj.getMandatoryStrValue(name);
				fields.add(new Variable(value));
			}
		}

		public String getName() {
			return name;
		}
		
		public void validate(String context, List<TAFException> exList) {
			String lctx = context + ":" + name;
			for(Variable field : fields) {
				field.validate(lctx, exList);
			}
		}
		
		@Override
		public String toString() {
			StringBuffer sb = new StringBuffer();
			sb.append(name);
			sb.append("=[");
			for(Variable var : fields) {
				if(fOPType == FIELD_OP_TYPE.BASIC_RESOLUTION) {
					sb.append(var.toString());
				} else if(fOPType == FIELD_OP_TYPE.CONCAT) {
					sb.append(var.getValue().getUTF8String());
				}
			}
			sb.append("]");
			return sb.toString();
		}
		
		public UTF8String getParameterValue(SystemProc system, Map<String, UTF8String> cache,
				Map<String, UTF8String> data, IOPDataImpl outputs, Map<String, UTF8String> constants) {
			UTF8String value = null;
			if(fOPType == FIELD_OP_TYPE.BASIC_RESOLUTION) {
				Variable var = fields.get(0);
				value = FWUtils.getParameterValue(var, system, cache, data, outputs, null, constants);
			} else if(fOPType == FIELD_OP_TYPE.CONCAT) {
				StringBuffer sb = new StringBuffer();
				for(Variable var : fields) {
					UTF8String lvalue = FWUtils.getParameterValue(var, system, cache, data, outputs, null, constants);
					if(lvalue != null) {
						sb.append(lvalue.getUTF8String());
					}
				}
				value = new UTF8String(sb.toString());
			}
			return value;
		}
	}

	public class Validation {
		public VALIDATION_TYPE validationType;
		public VALIDATION_DATA_TYPE dataType;

		public Variable output;
		public Variable expectedOutput;
		public String customValidationName;

		public void validate(String context, List<TAFException> exList) {
			context += ":Validation:";
			if (validationType == null || validationType == VALIDATION_TYPE.UNKNOWN) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " validationType is invalid"));
			}
			if (validationType == VALIDATION_TYPE.CUSTOM) {
				if (customValidationName == null || customValidationName.isEmpty()) {
					exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS,
							context + " customValidationName is invalid"));
				}
			} else {
				if (dataType == null || dataType == VALIDATION_DATA_TYPE.UNKNOWN) {
					exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " dataType is invalid"));
				}
				if (output == null) {
					exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " var is null"));
				} else {
					output.validate(context, exList);
				}
				// if unary then match can be null
				if (!validationType.isUnary()) {
					if (expectedOutput == null) {
						exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " match is null"));
					} else {
						expectedOutput.validate(context, exList);
					}
				}
			}
		}
	}

	public class Operation {
		public String name;
		public int id = 0;
		public Map<String, InputField> inputs;
		public List<Validation> validations;
		public Map<String, Variable> cache;

		public void validate(String context, List<TAFException> exList) {
			context += ":OP-" + name + ":";
			if (name == null || name.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " name is null or empty"));
			}
			if (inputs == null || inputs.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " inputs is null or empty"));
			} else {
				String ictx = context + ":inputs-";
				for (Map.Entry<String, InputField> pair : inputs.entrySet()) {
					InputField param = pair.getValue();
					param.validate(ictx, exList);
				}
			}
			if (validations == null || validations.isEmpty()) {
			} else {
				String ictx = context + ":validations-";
				for (Validation val : validations) {
					val.validate(ictx, exList);
				}
			}
		}
	}

	public class TestCase {
		public String name;
		public List<Operation> operations;

		public void validate(String context, List<TAFException> exList) {
			context += ":TC-" + name + ":";
			if (name == null || name.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " name is null or empty"));
			}
			if (operations == null || operations.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " operations is null or empty"));
			} else {
				String ictx = context + ":operations-";
				for (Operation op : operations) {
					op.validate(ictx, exList);
				}
			}
		}
	}

	public class TestSuite {
		public String name;
		public String dfName;
		public List<TestCase> testCases;
		public List<Operation> initOps;

		public void validate(String context, List<TAFException> exList) {
			context += ":TS-" + name + ":";
			if (name == null || name.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " name is null or empty"));
			}
			if (dfName == null || dfName.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " dfName is null or empty"));
			}
			if (testCases == null || testCases.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " testCases is null or empty"));
			} else {
				String ictx = context + ":testCases-";
				for (TestCase tc : testCases) {
					tc.validate(ictx, exList);
				}
			}
			if (initOps != null && !initOps.isEmpty()) {
				String ictx = context + ":initOps-";
				for (Operation op : initOps) {
					op.validate(ictx, exList);
				}
			}
		}
	}

	public class DataFile {
		public String name;
		public Map<String, UTF8String> initData;
		public List<Map<String, UTF8String>> data;
		public Map<String, UTF8String> constants;

		public void validate(String context, List<TAFException> exList) {
			context += ":DF-" + name + ":";
			if (name == null || name.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " name is null or empty"));
			}
			if (data == null || data.isEmpty()) {
				exList.add(new TAFException(ProcessingCode.INVALID_CONTENTS, context + " data is null or empty"));
			}
		}
	}

	public class OperationRunResults {
		private String name;
		private List<BasicValidator> results;
		private TAFLogger tsLogger;

		OperationRunResults(String name, TAFLogger tsLogger) {
			this.name = name;
			this.tsLogger = tsLogger;
			results = new ArrayList<BasicValidator>();
		}

		public String getName() {
			return name;
		}

		TAFLogger getTSLogger() {
			return tsLogger;
		}
		
		public List<BasicValidator> getResults() {
			return results;
		}
	}

	public class TestCaseRunResults {
		private String name;
		private List<OperationRunResults> results;
		
		TestCaseRunResults(String name) {
			this.name = name;
			results = new ArrayList<OperationRunResults>();
		}

		public String getName() {
			return name;
		}

		public List<OperationRunResults> getResults() {
			return results;
		}
	}

	public class TestSuiteRunResults {
		private int runId;
		private List<TestCaseRunResults> results;

		TestSuiteRunResults(int runId) {
			this.runId = runId;
			results = new ArrayList<TestCaseRunResults>();
		}

		public int getRunId() {
			return runId;
		}

		public List<TestCaseRunResults> getResults() {
			return results;
		}
	}
	
	public class SystemProc {
		private UTF8String runID;
		private UTF8String ctms;
		private Random rand;
		
		public SystemProc(int runID) {
			this.runID = new UTF8String(Integer.toString(runID));
			long ct = System.currentTimeMillis();
			this.ctms = new UTF8String(Long.toString(ct));
			this.rand = new Random();
			this.rand.setSeed(ct);
		}
		
		private UTF8String getRunID() {
			return runID;
		}
		
		private UTF8String getCTMS() {
			return ctms;
		}
		
		private UTF8String getRandom() {
			int rv = rand.nextInt();
			return new UTF8String(Integer.toString(rv));
		}
		
		public UTF8String getValue(String field) {
			UTF8String value = null;
			if(field.equalsIgnoreCase("runID")) {
				value = getRunID();
			} else if(field.equalsIgnoreCase("ctms")) {
				value = getCTMS();
			} else if(field.equalsIgnoreCase("random")) {
				value = getRandom();
			}
			return value;
		}
	}
}

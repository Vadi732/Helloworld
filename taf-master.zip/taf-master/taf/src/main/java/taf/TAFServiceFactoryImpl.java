package taf;

import taf.te.interfaces.HttpCommunicator;
import taf.te.interfaces.TAFJSONFactory;
import taf.te.interfaces.TAFServicesFactory;
import taf.util.HTTPStatistics;
import taf.util.HttpCommunicatorImpl;
import taf.util.TAFJSONFactoryImpl;

public class TAFServiceFactoryImpl implements TAFServicesFactory {
	HTTPStatistics httpStatistics;
	
	public TAFServiceFactoryImpl(HTTPStatistics httpStatistics) {
		this.httpStatistics = httpStatistics;
	}
	public TAFJSONFactory getJSONFactory() {
		return new TAFJSONFactoryImpl();
	}
	
	public HttpCommunicator getHttpCommunicator() {
		return new HttpCommunicatorImpl(httpStatistics);
	}
}
